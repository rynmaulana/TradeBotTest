"""
Main Risk Controller: mengintegrasikan semua risk modules.
"""
import pandas as pd
from typing import Dict, Optional
from dataclasses import dataclass
from config.settings import SETTINGS, SymbolConfig, TradeDirection
from risk.drawdown import DrawdownTracker
from risk.volatility_filter import VolatilityFilter
from risk.news_blackout import NewsBlackout
from data.storage import DataStorage
from utils.logger import get_logger

logger = get_logger("risk.manager")


@dataclass
class RiskCheckResult:
    allowed: bool
    reason: str
    position_size: float
    leverage: int
    stop_loss: Optional[float] = None
    take_profit: Optional[float] = None


class RiskManager:
    def __init__(self):
        self.drawdown = DrawdownTracker()
        self.volatility = VolatilityFilter()
        self.news = NewsBlackout()
        self.storage = DataStorage()
        self.daily_pnl = 0.0
        self.daily_trades = 0
        self.max_daily_trades = 10
    
    def update_equity(self, equity: float):
        """Update equity tracking."""
        self.drawdown.update(equity)
    
    def pre_trade_check(
        self,
        symbol_config: SymbolConfig,
        df: pd.DataFrame,
        direction: TradeDirection,
        entry_price: float,
        available_balance: float
    ) -> RiskCheckResult:
        """
        Comprehensive pre-trade risk check.
        """
        # 1. Check circuit breaker / drawdown
        if not self.drawdown.can_trade():
            return RiskCheckResult(
                allowed=False,
                reason="Circuit breaker active - max drawdown reached",
                position_size=0,
                leverage=0
            )
        
        # 2. Check news blackout
        if not self.news.check_trading_allowed():
            return RiskCheckResult(
                allowed=False,
                reason="News blackout active",
                position_size=0,
                leverage=0
            )
        
        # 3. Check daily loss limit
        daily_loss_limit = available_balance * SETTINGS.risk.max_daily_loss_pct
        if self.daily_pnl <= -daily_loss_limit:
            return RiskCheckResult(
                allowed=False,
                reason=f"Daily loss limit reached: {self.daily_pnl:.2f}",
                position_size=0,
                leverage=0
            )
        
        # 4. Check daily trade limit
        if self.daily_trades >= self.max_daily_trades:
            return RiskCheckResult(
                allowed=False,
                reason=f"Daily trade limit reached: {self.daily_trades}",
                position_size=0,
                leverage=0
            )
        
        # 5. Volatility filter
        vol_analysis = self.volatility.analyze(df)
        if vol_analysis['skip_trade']:
            return RiskCheckResult(
                allowed=False,
                reason=f"Volatility filter: {vol_analysis['volatility_regime']} (ATR: {vol_analysis['atr_pct']:.2%})",
                position_size=0,
                leverage=0
            )
        
        # 6. Calculate position size
        risk_per_trade = available_balance * SETTINGS.risk.default_risk_per_trade_pct
        atr = vol_analysis['atr']
        
        if atr > 0:
            # Position size = Risk Amount / (ATR * multiplier)
            risk_amount = entry_price * (SETTINGS.risk.atr_multiplier_sl * atr / entry_price)
            position_size_usd = risk_per_trade / (SETTINGS.risk.atr_multiplier_sl * atr / entry_price)
        else:
            position_size_usd = 0
        
        # Cap position size
        max_position = available_balance * symbol_config.max_position_size_pct
        position_size_usd = min(position_size_usd, max_position)
        
        # Apply volatility multiplier
        position_size_usd *= vol_analysis['position_size_multiplier']
        
        # Minimum order size check
        if position_size_usd < symbol_config.min_order_size:
            return RiskCheckResult(
                allowed=False,
                reason=f"Position size too small: ${position_size_usd:.2f}",
                position_size=0,
                leverage=0
            )
        
        # Calculate SL/TP
        sl = self.volatility.calculate_stop_loss(df, entry_price, direction.value)
        tp = self.volatility.calculate_take_profit(df, entry_price, direction.value)
        
        # Adjust leverage
        leverage = min(symbol_config.leverage, vol_analysis.get('recommended_leverage', 5))
        
        return RiskCheckResult(
            allowed=True,
            reason="Risk check passed",
            position_size=position_size_usd,
            leverage=leverage,
            stop_loss=sl,
            take_profit=tp
        )
    
    def record_trade_result(self, pnl: float):
        """Record trade PnL untuk daily tracking."""
        self.daily_pnl += pnl
        self.daily_trades += 1
    
    def reset_daily_stats(self):
        """Reset daily stats (call at midnight UTC)."""
        self.daily_pnl = 0.0
        self.daily_trades = 0
        logger.info("Daily risk stats reset")
