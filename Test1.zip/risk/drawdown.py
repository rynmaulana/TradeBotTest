"""
Maximum drawdown tracker dengan circuit breaker.
"""
import pandas as pd
import numpy as np
from typing import Dict, List, Tuple
from dataclasses import dataclass
from datetime import datetime
from config.settings import SETTINGS
from utils.logger import get_logger

logger = get_logger("risk.drawdown")


@dataclass
class DrawdownSnapshot:
    timestamp: datetime
    equity: float
    peak: float
    drawdown_pct: float
    recovery: bool


class DrawdownTracker:
    def __init__(self, max_drawdown_pct: float = None):
        self.max_allowed = max_drawdown_pct or SETTINGS.risk.max_drawdown_pct
        self.peak_equity = 0.0
        self.current_equity = 0.0
        self.history: List[DrawdownSnapshot] = []
        self.circuit_breaker_triggered = False
        self.circuit_breaker_time: Optional[datetime] = None
    
    def update(self, equity: float):
        """Update equity dan tracking."""
        self.current_equity = equity
        
        if equity > self.peak_equity:
            self.peak_equity = equity
        
        dd_pct = (self.peak_equity - equity) / self.peak_equity if self.peak_equity > 0 else 0
        
        snapshot = DrawdownSnapshot(
            timestamp=datetime.utcnow(),
            equity=equity,
            peak=self.peak_equity,
            drawdown_pct=dd_pct,
            recovery=equity >= self.peak_equity * 0.99
        )
        self.history.append(snapshot)
        
        # Check circuit breaker
        if dd_pct >= self.max_allowed:
            if not self.circuit_breaker_triggered:
                self.circuit_breaker_triggered = True
                self.circuit_breaker_time = datetime.utcnow()
                logger.critical(f"CIRCUIT BREAKER TRIGGERED! Drawdown: {dd_pct:.2%}")
        
        # Auto-reset jika recovery
        if snapshot.recovery and self.circuit_breaker_triggered:
            self.circuit_breaker_triggered = False
            self.circuit_breaker_time = None
            logger.info("Circuit breaker reset - equity recovered")
    
    def get_status(self) -> Dict[str, any]:
        """Get current drawdown status."""
        if not self.history:
            return {
                'current_drawdown': 0.0,
                'max_drawdown': 0.0,
                'peak': self.peak_equity,
                'circuit_breaker': False
            }
        
        max_dd = max(s.drawdown_pct for s in self.history)
        current = self.history[-1].drawdown_pct
        
        return {
            'current_drawdown': float(current),
            'max_drawdown': float(max_dd),
            'peak': float(self.peak_equity),
            'current_equity': float(self.current_equity),
            'circuit_breaker': self.circuit_breaker_triggered,
            'circuit_breaker_since': self.circuit_breaker_time.isoformat() if self.circuit_breaker_time else None
        }
    
    def can_trade(self) -> bool:
        """Check apakah boleh trading."""
        if self.circuit_breaker_triggered:
            # Cooldown 24 jam setelah circuit breaker
            if self.circuit_breaker_time:
                hours_since = (datetime.utcnow() - self.circuit_breaker_time).total_seconds() / 3600
                if hours_since < 24:
                    return False
                # Auto reset setelah 24 jam
                self.circuit_breaker_triggered = False
        return True
