"""
News event blackout: pause trading during high-impact economic events.
"""
import aiohttp
import pandas as pd
from datetime import datetime, timedelta
from typing import Dict, List, Optional
from config.settings import SETTINGS
from utils.logger import get_logger

logger = get_logger("risk.news")


class NewsBlackout:
    def __init__(self):
        self.blackout_minutes = SETTINGS.risk.news_blackout_minutes
        self.high_impact_events: List[Dict] = []
        self.last_check: Optional[datetime] = None
    
    async def fetch_economic_calendar(self) -> List[Dict]:
        """Fetch high-impact economic events (placeholder untuk forex factory atau similar)."""
        # Dalam implementasi nyata, gunakan API seperti ForexFactory, Investing.com, atau Bloomberg
        # Disini kita simulasikan struktur
        
        try:
            # Contoh: Check dari API ekonomi (mock)
            # async with aiohttp.ClientSession() as session:
            #     async with session.get("https://economic-calendar-api.example.com/events") as resp:
            #         data = await resp.json()
            
            # Return mock structure untuk demo
            return []
            
        except Exception as e:
            logger.error(f"Error fetching economic calendar: {e}")
            return []
    
    def is_blackout_active(self, events: List[Dict] = None) -> Dict[str, any]:
        """
        Check apakah sedang dalam blackout period.
        Blackout aktif 30 menit sebelum dan sesudah high-impact news.
        """
        now = datetime.utcnow()
        
        # Default: cek beberapa event hardcoded yang umum (untuk demo)
        # Dalam produksi, ini harus dari API real-time
        mock_events = events or []
        
        # Tambahkan event crypto-specific yang high impact
        crypto_events = [
            # FOMC meetings (contoh schedule)
            # {'time': '2024-01-31 19:00', 'impact': 'high', 'name': 'FOMC Statement'},
        ]
        all_events = mock_events + crypto_events
        
        for event in all_events:
            event_time = pd.to_datetime(event.get('time'))
            time_diff = abs((now - event_time).total_seconds() / 60)
            
            if time_diff < self.blackout_minutes and event.get('impact') == 'high':
                return {
                    'active': True,
                    'event': event.get('name', 'Unknown'),
                    'time_until': int(self.blackout_minutes - time_diff),
                    'reason': 'high_impact_news'
                }
        
        return {
            'active': False,
            'event': None,
            'time_until': 0,
            'reason': None
        }
    
    def check_trading_allowed(self) -> bool:
        """Quick check apakah trading diperbolehkan."""
        status = self.is_blackout_active()
        if status['active']:
            logger.warning(f"Trading PAUSED: {status['event']} in {status['time_until']} minutes")
            return False
        return True
