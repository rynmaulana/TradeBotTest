"""
ATR-based volatility filter dan position sizing.
"""
import pandas as pd
import numpy as np
from typing import Dict, Tuple
from config.settings import SETTINGS, SymbolConfig
from utils.logger import get_logger

logger = get_logger("risk.volatility")


class VolatilityFilter:
    def __init__(self, atr_period: int = 14, target_volatility: float = 0.02):
        self.atr_period = atr_period
        self.target_volatility = target_volatility  # 2% daily vol target
    
    def calculate_atr(self, df: pd.DataFrame) -> pd.Series:
        """Calculate Average True Range."""
        high_low = df['high'] - df['low']
        high_close = np.abs(df['high'] - df['close'].shift())
        low_close = np.abs(df['low'] - df['close'].shift())
        tr = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
        return tr.rolling(self.atr_period).mean()
    
    def analyze(self, df: pd.DataFrame) -> Dict[str, any]:
        """Analisis volatilitas current market."""
        if len(df) < self.atr_period + 5:
            return {
                'atr': 0.0,
                'atr_pct': 0.0,
                'volatility_regime': 'unknown',
                'position_size_multiplier': 0.0,
                'skip_trade': True
            }
        
        atr = self.calculate_atr(df)
        current_atr = atr.iloc[-1]
        current_price = df['close'].iloc[-1]
        atr_pct = current_atr / current_price if current_price > 0 else 0
        
        # Volatility regime
        atr_sma = atr.rolling(50).mean().iloc[-1]
        
        regime = 'normal'
        if atr_pct > atr_sma / current_price * 1.5:
            regime = 'high'
        elif atr_pct < atr_sma / current_price * 0.5:
            regime = 'low'
        
        # Position sizing: volatility targeting
        # Size = TargetVol / CurrentVol * BaseSize
        if atr_pct > 0:
            size_multiplier = min(2.0, self.target_volatility / atr_pct)
        else:
            size_multiplier = 0.0
        
        # Skip trade jika terlalu volatile atau terlalu illiquid
        skip = False
        if regime == 'high' and atr_pct > 0.05:  # >5% ATR skip
            skip = True
            logger.warning(f"Skipping trade: ATR too high ({atr_pct:.2%})")
        elif regime == 'low' and atr_pct < 0.001:  # <0.1% ATR (dead market)
            skip = True
        
        return {
            'atr': float(current_atr),
            'atr_pct': float(atr_pct),
            'volatility_regime': regime,
            'position_size_multiplier': float(size_multiplier),
            'skip_trade': skip,
            'recommended_leverage': max(1, int(5 * size_multiplier))  # Adjust leverage
        }
    
    def calculate_stop_loss(
        self, 
        df: pd.DataFrame, 
        entry_price: float, 
        direction: str,
        multiplier: float = None
    ) -> float:
        """Calculate ATR-based stop loss."""
        mult = multiplier or SETTINGS.risk.atr_multiplier_sl
        atr = self.calculate_atr(df).iloc[-1]
        
        if direction == 'LONG':
            return entry_price - (atr * mult)
        else:
            return entry_price + (atr * mult)
    
    def calculate_take_profit(
        self, 
        df: pd.DataFrame, 
        entry_price: float, 
        direction: str,
        multiplier: float = None
    ) -> float:
        """Calculate ATR-based take profit."""
        mult = multiplier or SETTINGS.risk.atr_multiplier_tp
        atr = self.calculate_atr(df).iloc[-1]
        
        if direction == 'LONG':
            return entry_price + (atr * mult)
        else:
            return entry_price - (atr * mult)
