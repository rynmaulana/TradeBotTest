"""
Local data storage menggunakan SQLite untuk caching & history.
"""
import sqlite3
import pandas as pd
import json
from datetime import datetime
from pathlib import Path
from typing import Optional
from config.settings import SETTINGS
from utils.logger import get_logger

logger = get_logger("data.storage")


class DataStorage:
    def __init__(self, db_path: Optional[str] = None):
        self.db_path = db_path or f"{SETTINGS.data_dir}/autotrade.db"
        Path(SETTINGS.data_dir).mkdir(parents=True, exist_ok=True)
        self._init_tables()
    
    def _init_tables(self):
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS ohlcv (
                    symbol TEXT,
                    timeframe TEXT,
                    timestamp TEXT,
                    open REAL,
                    high REAL,
                    low REAL,
                    close REAL,
                    volume REAL,
                    PRIMARY KEY (symbol, timeframe, timestamp)
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS trades (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT,
                    symbol TEXT,
                    direction TEXT,
                    entry_price REAL,
                    exit_price REAL,
                    size REAL,
                    pnl REAL,
                    pnl_pct REAL,
                    fees REAL,
                    strategy TEXT,
                    metadata TEXT
                )
            """)
            conn.execute("""
                CREATE TABLE IF NOT EXISTS signals (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp TEXT,
                    symbol TEXT,
                    source TEXT,
                    direction TEXT,
                    confidence REAL,
                    metadata TEXT
                )
            """)
            conn.commit()
    
    def save_ohlcv(self, df: pd.DataFrame, symbol: str, timeframe: str):
        """Simpan/update data OHLCV ke SQLite."""
        if df.empty:
            return
        
        df_copy = df.reset_index()
        df_copy['symbol'] = symbol
        df_copy['timeframe'] = timeframe
        
        with sqlite3.connect(self.db_path) as conn:
            # Insert or replace
            for _, row in df_copy.iterrows():
                conn.execute("""
                    INSERT OR REPLACE INTO ohlcv 
                    (symbol, timeframe, timestamp, open, high, low, close, volume)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    row['symbol'], row['timeframe'], str(row['timestamp']),
                    row['open'], row['high'], row['low'], 
                    row['close'], row['volume']
                ))
            conn.commit()
        logger.debug(f"Saved {len(df_copy)} OHLCV rows for {symbol}")
    
    def load_ohlcv(self, symbol: str, timeframe: str, limit: int = 1000) -> pd.DataFrame:
        """Load OHLCV dari cache."""
        with sqlite3.connect(self.db_path) as conn:
            query = """
                SELECT * FROM ohlcv 
                WHERE symbol = ? AND timeframe = ?
                ORDER BY timestamp DESC
                LIMIT ?
            """
            df = pd.read_sql_query(query, conn, params=(symbol, timeframe, limit))
        
        if not df.empty:
            df['timestamp'] = pd.to_datetime(df['timestamp'])
            df.set_index('timestamp', inplace=True)
            df.sort_index(inplace=True)
        
        return df
    
    def save_trade(self, trade_data: dict):
        """Simpan record trade."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                INSERT INTO trades 
                (timestamp, symbol, direction, entry_price, exit_price, size, pnl, pnl_pct, fees, strategy, metadata)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            """, (
                datetime.utcnow().isoformat(),
                trade_data.get('symbol'),
                trade_data.get('direction'),
                trade_data.get('entry_price'),
                trade_data.get('exit_price'),
                trade_data.get('size'),
                trade_data.get('pnl'),
                trade_data.get('pnl_pct'),
                trade_data.get('fees'),
                trade_data.get('strategy'),
                json.dumps(trade_data.get('metadata', {}))
            ))
            conn.commit()
    
    def save_signal(self, symbol: str, source: str, direction: str, confidence: float, metadata: dict):
        """Simpan signal history."""
        with sqlite3.connect(self.db_path) as conn:
            conn.execute("""
                INSERT INTO signals (timestamp, symbol, source, direction, confidence, metadata)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                datetime.utcnow().isoformat(),
                symbol, source, direction, confidence,
                json.dumps(metadata)
            ))
            conn.commit()
    
    def get_recent_trades(self, symbol: Optional[str] = None, limit: int = 50) -> pd.DataFrame:
        """Ambil trade history terakhir."""
        with sqlite3.connect(self.db_path) as conn:
            if symbol:
                query = "SELECT * FROM trades WHERE symbol = ? ORDER BY timestamp DESC LIMIT ?"
                df = pd.read_sql_query(query, conn, params=(symbol, limit))
            else:
                query = "SELECT * FROM trades ORDER BY timestamp DESC LIMIT ?"
                df = pd.read_sql_query(query, conn, params=(limit,))
        return df
