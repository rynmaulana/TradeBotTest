"""
Market data fetcher menggunakan CCXT untuk Binance Futures.
"""
import asyncio
import ccxt.async_support as ccxt
import pandas as pd
from typing import Optional, List, Dict, Any
from datetime import datetime, timedelta

from config.settings import SETTINGS, SymbolConfig
from config.credentials import CREDS
from utils.logger import get_logger

logger = get_logger("data.fetcher")


class DataFetcher:
    def __init__(self):
        self.exchange: Optional[ccxt.binance] = None
        self._initialized = False
    
    async def initialize(self):
        """Inisialisasi koneksi CCXT ke Binance Futures."""
        if self._initialized:
            return
        
        config = {
            'apiKey': CREDS.binance_api_key,
            'secret': CREDS.binance_secret_key,
            'enableRateLimit': True,
            'options': {
                'defaultType': 'future',  # Binance Futures USD-M
            }
        }
        
        if SETTINGS.sandbox:
            config['sandbox'] = True
            logger.info("Using Binance TESTNET (sandbox mode)")
        
        self.exchange = ccxt.binance(config)
        await self.exchange.load_markets()
        self._initialized = True
        logger.info("DataFetcher initialized successfully")
    
    async def fetch_ohlcv(
        self,
        symbol_config: SymbolConfig,
        limit: int = 500,
        since: Optional[int] = None
    ) -> pd.DataFrame:
        """Fetch candlestick data (OHLCV)."""
        await self.initialize()
        
        try:
            timeframe = symbol_config.timeframe
            symbol = symbol_config.symbol
            
            # Format symbol for CCXT if needed
            if '/' not in symbol:
                symbol = symbol.replace('USDT', '/USDT')
            
            ohlcv = await self.exchange.fetch_ohlcv(
                symbol, timeframe, since=since, limit=limit
            )
            
            df = pd.DataFrame(
                ohlcv, 
                columns=['timestamp', 'open', 'high', 'low', 'close', 'volume']
            )
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            df.set_index('timestamp', inplace=True)
            
            # Convert to float
            for col in ['open', 'high', 'low', 'close', 'volume']:
                df[col] = pd.to_numeric(df[col], errors='coerce')
            
            logger.debug(f"Fetched {len(df)} candles for {symbol} ({timeframe})")
            return df
            
        except Exception as e:
            logger.error(f"Error fetching OHLCV for {symbol_config.symbol}: {e}")
            raise
    
    async def fetch_funding_rate(
        self,
        symbol: str,
        limit: int = 100
    ) -> pd.DataFrame:
        """Fetch historical funding rates."""
        await self.initialize()
        
        try:
            if '/' not in symbol:
                symbol = symbol.replace('USDT', '/USDT')
            
            rates = await self.exchange.fetchFundingRateHistory(symbol, limit=limit)
            df = pd.DataFrame(rates)
            if not df.empty:
                df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
                df.set_index('timestamp', inplace=True)
                df['fundingRate'] = pd.to_numeric(df['fundingRate'], errors='coerce')
            return df
        except Exception as e:
            logger.error(f"Error fetching funding rate: {e}")
            return pd.DataFrame()
    
    async def fetch_orderbook(self, symbol: str, limit: int = 20) -> Dict[str, Any]:
        """Fetch order book untuk slippage analysis."""
        await self.initialize()
        try:
            if '/' not in symbol:
                symbol = symbol.replace('USDT', '/USDT')
            ob = await self.exchange.fetch_order_book(symbol, limit=limit)
            return ob
        except Exception as e:
            logger.error(f"Error fetching orderbook: {e}")
            return {}
    
    async def fetch_balance(self) -> Dict[str, Any]:
        """Fetch futures account balance."""
        await self.initialize()
        try:
            balance = await self.exchange.fetch_balance({'type': 'future'})
            return balance
        except Exception as e:
            logger.error(f"Error fetching balance: {e}")
            return {}
    
    async def close(self):
        """Cleanup resources."""
        if self.exchange:
            await self.exchange.close()
            self._initialized = False
            logger.info("DataFetcher connection closed")