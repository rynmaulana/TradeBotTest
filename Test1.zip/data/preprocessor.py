"""
Data preprocessing pipeline.
"""
import pandas as pd
import numpy as np
from typing import Tuple
from utils.logger import get_logger

logger = get_logger("data.preprocessor")


class DataPreprocessor:
    @staticmethod
    def clean_ohlcv(df: pd.DataFrame) -> pd.DataFrame:
        """Bersihkan data OHLCV dari NaN dan outlier."""
        df = df.copy()
        
        # Drop NaN
        df.dropna(inplace=True)
        
        # Remove zero volume candles (illiquid)
        df = df[df['volume'] > 0]
        
        # Remove outliers (price spikes > 10% in single candle)
        returns = df['close'].pct_change().abs()
        df = df[returns < 0.10]
        
        return df
    
    @staticmethod
    def resample(df: pd.DataFrame, timeframe: str) -> pd.DataFrame:
        """Resample ke timeframe berbeda jika diperlukan."""
        rules = {
            '1h': '1H', '4h': '4H', '1d': '1D', 
            '15m': '15min', '30m': '30min'
        }
        rule = rules.get(timeframe, '1H')
        
        resampled = df.resample(rule).agg({
            'open': 'first',
            'high': 'max',
            'low': 'min',
            'close': 'last',
            'volume': 'sum'
        }).dropna()
        
        return resampled
    
    @staticmethod
    def normalize(df: pd.DataFrame, method: str = "zscore") -> pd.DataFrame:
        """Normalisasi kolom numerik."""
        numeric_cols = df.select_dtypes(include=[np.number]).columns
        df_norm = df.copy()
        
        if method == "zscore":
            df_norm[numeric_cols] = (df[numeric_cols] - df[numeric_cols].mean()) / df[numeric_cols].std()
        elif method == "minmax":
            df_norm[numeric_cols] = (df[numeric_cols] - df[numeric_cols].min()) / (df[numeric_cols].max() - df[numeric_cols].min())
        
        return df_norm
    
    @staticmethod
    def add_time_features(df: pd.DataFrame) -> pd.DataFrame:
        """Tambahkan fitur waktu (hour, dayofweek, month)."""
        df = df.copy()
        df['hour'] = df.index.hour
        df['dayofweek'] = df.index.dayofweek
        df['month'] = df.index.month
        df['is_weekend'] = (df['dayofweek'] >= 5).astype(int)
        return df
    
    @staticmethod
    def train_test_split(
        df: pd.DataFrame, 
        test_size: float = 0.2
    ) -> Tuple[pd.DataFrame, pd.DataFrame]:
        """Split time-series data secara kronologis."""
        split_idx = int(len(df) * (1 - test_size))
        train = df.iloc[:split_idx].copy()
        test = df.iloc[split_idx:].copy()
        return train, test
