import unittest
import pandas as pd
import numpy as np
from ai.feature_engineer import FeatureEngineer
from ai.mirofish import MiroFishModel


class TestMiroFish(unittest.TestCase):
    def setUp(self):
        np.random.seed(42)
        dates = pd.date_range('2024-01-01', periods=500, freq='H')
        prices = 100 + np.random.randn(500).cumsum()
        self.df = pd.DataFrame({
            'open': prices,
            'high': prices + 2,
            'low': prices - 2,
            'close': prices,
            'volume': np.random.randint(1000, 10000, 500)
        }, index=dates)
    
    def test_feature_engineering(self):
        fe = FeatureEngineer()
        X, y = fe.prepare_train_data(self.df)
        self.assertGreater(len(X.columns), 10)
        self.assertEqual(len(X), len(y))
    
    def test_model_training(self):
        model = MiroFishModel(model_dir="./models_test")
        result = model.train(self.df)
        self.assertIn('accuracy', result)
        self.assertIn('status', result)
        
        if result['status'] == 'trained':
            pred = model.predict(self.df)
            self.assertIn('confidence', pred)
            self.assertIn('probabilities', pred)


if __name__ == '__main__':
    unittest.main()
