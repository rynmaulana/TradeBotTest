import unittest
import pandas as pd
import numpy as np
from risk.volatility_filter import VolatilityFilter
from risk.drawdown import DrawdownTracker
from config.settings import TradeDirection


class TestRiskManagement(unittest.TestCase):
    def setUp(self):
        np.random.seed(42)
        dates = pd.date_range('2024-01-01', periods=100, freq='H')
        prices = 100 + np.random.randn(100).cumsum()
        self.df = pd.DataFrame({
            'open': prices,
            'high': prices + 1,
            'low': prices - 1,
            'close': prices,
            'volume': np.random.randint(1000, 5000, 100)
        }, index=dates)
    
    def test_atr_calculation(self):
        vol = VolatilityFilter()
        atr = vol.calculate_atr(self.df)
        self.assertTrue(len(atr) > 0)
        self.assertTrue(atr.iloc[-1] > 0)
    
    def test_drawdown_circuit_breaker(self):
        dd = DrawdownTracker(max_drawdown_pct=0.05)
        dd.update(10000)
        dd.update(9800)  # -2%
        self.assertFalse(dd.circuit_breaker_triggered)
        dd.update(9400)  # -6%
        self.assertTrue(dd.circuit_breaker_triggered)
        self.assertFalse(dd.can_trade())


if __name__ == '__main__':
    unittest.main()
