import unittest
from unittest.mock import AsyncMock, MagicMock, patch
from core.executor import Executor, OrderResult
from config.settings import SymbolConfig, TradeDirection


class TestExecutor(unittest.TestCase):
    def setUp(self):
        self.executor = Executor()
        self.executor.fetcher = MagicMock()
        self.executor.fetcher.exchange = MagicMock()
    
    def test_order_result(self):
        result = OrderResult(success=True, order_id="123", filled_price=50000, filled_qty=0.1, fee=1.0)
        self.assertTrue(result.success)
        self.assertEqual(result.order_id, "123")


if __name__ == '__main__':
    unittest.main()
