import unittest
import pandas as pd
import numpy as np
from analysis.ema import EMAAnalyzer
from analysis.macd import MACDAnalyzer
from analysis.rsi import RSIAnalyzer
from analysis.market_structure import MarketStructureAnalyzer
from config.settings import TradeDirection


class TestTechnicalAnalysis(unittest.TestCase):
    def setUp(self):
        # Generate sample data
        np.random.seed(42)
        dates = pd.date_range('2024-01-01', periods=300, freq='H')
        trend = np.linspace(100, 150, 300) + np.random.randn(300) * 5
        self.df = pd.DataFrame({
            'open': trend,
            'high': trend + 2,
            'low': trend - 2,
            'close': trend + np.random.randn(300),
            'volume': np.random.randint(1000, 10000, 300)
        }, index=dates)
    
    def test_ema_calculation(self):
        ema = EMAAnalyzer()
        result = ema.calculate(self.df)
        self.assertIn('ema_9', result.columns)
        self.assertIn('ema_200', result.columns)
    
    def test_macd_signal(self):
        macd = MACDAnalyzer()
        df = macd.calculate(self.df)
        signal = macd.generate_signal(df)
        self.assertIn('signal', signal)
        self.assertIn('strength', signal)
    
    def test_rsi_bounds(self):
        rsi = RSIAnalyzer()
        df = rsi.calculate(self.df)
        self.assertTrue(df['rsi'].min() >= 0)
        self.assertTrue(df['rsi'].max() <= 100)
    
    def test_market_structure(self):
        ms = MarketStructureAnalyzer()
        result = ms.generate_signal(self.df)
        self.assertIn('structure', result)
        self.assertIn('support_resistance', result)


if __name__ == '__main__':
    unittest.main()
