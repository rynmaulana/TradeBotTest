"""
Global settings & configuration untuk AutoTrade Bot.
"""
import os
from dataclasses import dataclass, field
from typing import List, Dict, Optional
from enum import Enum


class MarketRegime(Enum):
    TRENDING = "trending"
    RANGING = "ranging"
    VOLATILE = "volatile"
    UNKNOWN = "unknown"


class TradeDirection(Enum):
    LONG = "LONG"
    SHORT = "SHORT"
    NEUTRAL = "NEUTRAL"


@dataclass
class SymbolConfig:
    symbol: str                    # e.g., "BTC/USDT"
    timeframe: str = "1h"          # OHLCV timeframe
    leverage: int = 5
    max_position_size_pct: float = 0.15  # 15% dari portfolio per trade
    min_order_size: float = 10.0     # USDT minimum


@dataclass
class TechnicalWeights:
    ema: float = 0.20
    macd: float = 0.20
    rsi: float = 0.15
    market_structure: float = 0.25


@dataclass
class OnchainWeights:
    whale_tracker: float = 0.30
    funding_rate: float = 0.40
    open_interest: float = 0.30


@dataclass
class AIWeights:
    mirofish: float = 0.50
    sentiment: float = 0.30
    claude: float = 0.20


@dataclass
class RiskSettings:
    max_daily_loss_pct: float = 0.03      # 3% max daily loss
    max_drawdown_pct: float = 0.10        # 10% max drawdown
    default_risk_per_trade_pct: float = 0.01  # 1% risk per trade
    volatility_lookback: int = 14
    atr_multiplier_sl: float = 2.0       # ATR multiplier for stop loss
    atr_multiplier_tp: float = 3.0       # ATR multiplier for take profit
    use_kelly_criterion: bool = False
    kelly_fraction: float = 0.5            # Half-Kelly
    news_blackout_minutes: int = 30        # Pause 30 min before/after high impact news


@dataclass
class AppSettings:
    app_name: str = "AutoTrade"
    version: str = "2.0.0"
    mode: str = "paper"                    # "paper" | "live"
    exchange_id: str = "binance"
    sandbox: bool = True                 # Use Binance testnet
    
    symbols: List[SymbolConfig] = field(default_factory=lambda: [
        SymbolConfig(symbol="BTC/USDT", timeframe="1h", leverage=5),
        SymbolConfig(symbol="ETH/USDT", timeframe="1h", leverage=5),
    ])
    
    technical_weights: TechnicalWeights = field(default_factory=TechnicalWeights)
    onchain_weights: OnchainWeights = field(default_factory=OnchainWeights)
    ai_weights: AIWeights = field(default_factory=AIWeights)
    risk: RiskSettings = field(default_factory=RiskSettings)
    
    # Dynamic weight adjustment thresholds
    regime_weights_adjustment: Dict[MarketRegime, Dict[str, float]] = field(default_factory=lambda: {
        MarketRegime.TRENDING: {"technical": 0.50, "onchain": 0.20, "ai": 0.30},
        MarketRegime.RANGING: {"technical": 0.30, "onchain": 0.30, "ai": 0.40},
        MarketRegime.VOLATILE: {"technical": 0.25, "onchain": 0.45, "ai": 0.30},
    })
    
    # ML Settings
    model_retrain_interval_hours: int = 24
    prediction_threshold: float = 0.60     # Minimum confidence to trade
    
    # Execution
    max_slippage_pct: float = 0.1
    order_timeout_seconds: int = 30
    
    # Paths
    data_dir: str = "./data"
    logs_dir: str = "./logs"
    models_dir: str = "./models"
    
    @classmethod
    def from_env(cls) -> "AppSettings":
        """Load critical overrides from environment variables."""
        settings = cls()
        if os.getenv("AUTOTRADE_MODE") == "live":
            settings.mode = "live"
        if os.getenv("AUTOTRADE_SANDBOX", "true").lower() == "false":
            settings.sandbox = False
        return settings


# Global instance
SETTINGS = AppSettings.from_env()
