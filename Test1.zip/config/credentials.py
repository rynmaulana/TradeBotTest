"""
API credentials & secure key management.
"""
import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()


@dataclass
class Credentials:
    # Binance API
    binance_api_key: str = ""
    binance_secret_key: str = ""
    
    # Coinglass API
    coinglass_api_key: str = ""
    
    # Whale Alert API
    whale_alert_api_key: str = ""
    
    # Anthropic (Claude)
    anthropic_api_key: str = ""
    
    # Telegram
    telegram_bot_token: str = ""
    telegram_chat_id: str = ""
    
    # Discord
    discord_webhook_url: str = ""
    
    def __post_init__(self):
        self.binance_api_key = os.getenv("BINANCE_API_KEY", "")
        self.binance_secret_key = os.getenv("BINANCE_SECRET_KEY", "")
        self.coinglass_api_key = os.getenv("COINGLASS_API_KEY", "")
        self.whale_alert_api_key = os.getenv("WHALE_ALERT_API_KEY", "")
        self.anthropic_api_key = os.getenv("ANTHROPIC_API_KEY", "")
        self.telegram_bot_token = os.getenv("TELEGRAM_BOT_TOKEN", "")
        self.telegram_chat_id = os.getenv("TELEGRAM_CHAT_ID", "")
        self.discord_webhook_url = os.getenv("DISCORD_WEBHOOK_URL", "")
    
    def validate(self) -> None:
        missing = []
        if not self.binance_api_key:
            missing.append("BINANCE_API_KEY")
        if not self.binance_secret_key:
            missing.append("BINANCE_SECRET_KEY")
        if missing:
            raise ValueError(f"Missing required credentials: {', '.join(missing)}")


CREDS = Credentials()
