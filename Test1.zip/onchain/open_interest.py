"""
Open Interest analysis via Coinglass API (atau fallback ke Binance).
"""
import aiohttp
import pandas as pd
from typing import Dict, Optional
from datetime import datetime
from config.credentials import CREDS
from config.settings import TradeDirection
from utils.logger import get_logger

logger = get_logger("onchain.oi")


class OpenInterestAnalyzer:
    def __init__(self):
        self.coinglass_key = CREDS.coinglass_api_key
        self.base_url = "https://open-api.coinglass.com/api/pro/v1"
        self.use_coinglass = bool(self.coinglass_key)
    
    async def fetch_open_interest(self, symbol: str = "BTC") -> pd.DataFrame:
        """Fetch Open Interest data."""
        if not self.use_coinglass:
            logger.warning("No Coinglass API key, returning empty OI data")
            return pd.DataFrame()
        
        try:
            # Normalize symbol
            symbol_clean = symbol.replace('/USDT', '').replace('USDT', '')
            
            async with aiohttp.ClientSession() as session:
                url = f"{self.base_url}/future/openInterest"
                headers = {'coinglassSecretKey': self.coinglass_key}
                params = {'symbol': symbol_clean, 'interval': '1h'}
                
                async with session.get(url, headers=headers, params=params) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        if data.get('success'):
                            oi_data = data.get('data', [])
                            df = pd.DataFrame(oi_data)
                            if not df.empty and 't' in df.columns:
                                df['timestamp'] = pd.to_datetime(df['t'], unit='ms')
                                df.set_index('timestamp', inplace=True)
                                df['oi'] = pd.to_numeric(df.get('o', 0), errors='coerce')
                            return df
                    
                    logger.error(f"Coinglass API error: {resp.status}")
                    return pd.DataFrame()
                    
        except Exception as e:
            logger.error(f"Error fetching OI: {e}")
            return pd.DataFrame()
    
    def analyze_oi_change(self, df: pd.DataFrame, price_change: float = 0) -> Dict[str, any]:
        """
        Analisis perubahan Open Interest vs Price.
        - OI up + Price up = Long buildup (bullish)
        - OI up + Price down = Short buildup (bearish)
        - OI down + Price up = Short squeeze (bullish)
        - OI down + Price down = Long liquidation (bearish)
        """
        if df.empty or len(df) < 2:
            return {'signal': TradeDirection.NEUTRAL, 'strength': 0.0, 'scenario': 'unknown'}
        
        oi_change = df['oi'].iloc[-1] - df['oi'].iloc[-2]
        oi_change_pct = oi_change / df['oi'].iloc[-2] if df['oi'].iloc[-2] != 0 else 0
        
        scenario = 'unknown'
        signal = TradeDirection.NEUTRAL
        strength = 0.0
        
        if oi_change_pct > 0.01:  # OI increased > 1%
            if price_change > 0:
                scenario = 'long_buildup'
                signal = TradeDirection.LONG
                strength = min(1.0, abs(price_change) * 10)
            elif price_change < 0:
                scenario = 'short_buildup'
                signal = TradeDirection.SHORT
                strength = min(1.0, abs(price_change) * 10)
        
        elif oi_change_pct < -0.01:  # OI decreased > 1%
            if price_change > 0:
                scenario = 'short_squeeze'
                signal = TradeDirection.LONG
                strength = min(1.0, abs(price_change) * 10 + 0.1)
            elif price_change < 0:
                scenario = 'long_liquidation'
                signal = TradeDirection.SHORT
                strength = min(1.0, abs(price_change) * 10 + 0.1)
        
        return {
            'signal': signal,
            'strength': strength,
            'scenario': scenario,
            'oi_change_pct': float(oi_change_pct),
            'price_change_pct': float(price_change)
        }
    
    async def generate_signal(self, symbol: str, price_change: float = 0) -> Dict[str, any]:
        """Generate signal dari OI analysis."""
        df = await self.fetch_open_interest(symbol)
        return self.analyze_oi_change(df, price_change)
