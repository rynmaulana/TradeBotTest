"""
Whale activity monitoring untuk deteksi akumulasi/distribusi besar.
"""
import aiohttp
import pandas as pd
from typing import Dict, List, Optional
from datetime import datetime, timedelta
from config.credentials import CREDS
from utils.logger import get_logger

logger = get_logger("onchain.whale")


class WhaleTracker:
    def __init__(self):
        self.api_key = CREDS.whale_alert_api_key
        self.base_url = "https://api.whale-alert.io/v1"
        self.min_value_usd = 10_000_000  # $10M+ considered whale
        self.recent_transactions: List[Dict] = []
    
    async def fetch_whale_transactions(
        self, 
        symbol: str = "btc",
        hours: int = 24,
        min_value: Optional[float] = None
    ) -> pd.DataFrame:
        """
        Fetch whale transactions dari Whale Alert API.
        Note: Requires API key untuk data lengkap.
        """
        min_val = min_value or self.min_value_usd
        
        # Simulasi data jika tidak ada API key (untuk struktur)
        if not self.api_key:
            logger.warning("No Whale Alert API key, returning simulated structure")
            return self._simulate_whale_data(symbol, hours)
        
        try:
            start_time = int((datetime.utcnow() - timedelta(hours=hours)).timestamp())
            
            async with aiohttp.ClientSession() as session:
                url = f"{self.base_url}/transactions"
                params = {
                    'api_key': self.api_key,
                    'start': start_time,
                    'min_value': min_val,
                    'currency': symbol.lower()
                }
                
                async with session.get(url, params=params) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        transactions = data.get('transactions', [])
                        self.recent_transactions = transactions
                        
                        df = pd.DataFrame(transactions)
                        if not df.empty:
                            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='s')
                        return df
                    else:
                        logger.error(f"Whale Alert API error: {resp.status}")
                        return pd.DataFrame()
                        
        except Exception as e:
            logger.error(f"Error fetching whale data: {e}")
            return pd.DataFrame()
    
    def _simulate_whale_data(self, symbol: str, hours: int) -> pd.DataFrame:
        """Generate struktur data kosong dengan schema yang benar."""
        return pd.DataFrame(columns=[
            'timestamp', 'from_owner', 'to_owner', 'amount', 
            'amount_usd', 'transaction_type', 'symbol'
        ])
    
    def analyze_whale_pressure(self, df: pd.DataFrame) -> Dict[str, any]:
        """
        Analisis apakah whale sedang akumulasi (accumulation) atau distribusi (distribution).
        """
        if df.empty:
            return {'pressure': 'neutral', 'strength': 0.0, 'net_flow': 0}
        
        # Klasifikasikan inflow vs outflow dari exchange
        inflow = df[df['to_owner_type'] == 'exchange']['amount_usd'].sum() if 'to_owner_type' in df.columns else 0
        outflow = df[df['from_owner_type'] == 'exchange']['amount_usd'].sum() if 'from_owner_type' in df.columns else 0
        
        net_flow = outflow - inflow  # Positive = more outflow (accumulation)
        
        pressure = 'neutral'
        strength = 0.0
        
        total_volume = df['amount_usd'].sum()
        if total_volume > 0:
            ratio = abs(net_flow) / total_volume
            
            if net_flow > 0:
                pressure = 'accumulation'  # Keluar dari exchange = bullish
                strength = min(1.0, ratio * 2)
            elif net_flow < 0:
                pressure = 'distribution'  # Masuk ke exchange = bearish
                strength = min(1.0, ratio * 2)
        
        return {
            'pressure': pressure,
            'strength': strength,
            'net_flow': float(net_flow),
            'inflow': float(inflow),
            'outflow': float(outflow),
            'transaction_count': len(df)
        }
    
    def generate_signal(self, df: pd.DataFrame) -> Dict[str, any]:
        """Generate trading signal dari whale activity."""
        analysis = self.analyze_whale_pressure(df)
        
        from config.settings import TradeDirection
        
        signal = TradeDirection.NEUTRAL
        if analysis['pressure'] == 'accumulation' and analysis['strength'] > 0.3:
            signal = TradeDirection.LONG
        elif analysis['pressure'] == 'distribution' and analysis['strength'] > 0.3:
            signal = TradeDirection.SHORT
        
        return {
            'signal': signal,
            'strength': analysis['strength'],
            'metadata': analysis
        }
