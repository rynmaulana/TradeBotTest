"""
Funding rate analysis untuk Binance Futures.
"""
import aiohttp
import pandas as pd
import numpy as np
from typing import Dict
from config.settings import TradeDirection
from data.fetcher import DataFetcher
from utils.logger import get_logger

logger = get_logger("onchain.funding")


class FundingRateAnalyzer:
    def __init__(self):
        self.extreme_threshold = 0.01  # 1% funding = extreme
        self.history_window = 30  # 30 periods average
    
    async def fetch_and_analyze(self, fetcher: DataFetcher, symbol: str) -> Dict[str, any]:
        """Fetch dan analisis funding rate."""
        try:
            df = await fetcher.fetch_funding_rate(symbol, limit=100)
            
            if df.empty or 'fundingRate' not in df.columns:
                return self._default_analysis()
            
            current = df['fundingRate'].iloc[-1]
            avg = df['fundingRate'].iloc[-self.history_window:].mean()
            max_hist = df['fundingRate'].max()
            min_hist = df['fundingRate'].min()
            
            # Extreme funding = crowded trade (contrarian signal)
            deviation = current - avg
            percentile = (current - min_hist) / (max_hist - min_hist) if max_hist != min_hist else 0.5
            
            signal = TradeDirection.NEUTRAL
            strength = 0.0
            interpretation = 'neutral'
            
            # Very positive funding = longs paying shorts (crowded long) -> bearish contrarian
            if current > self.extreme_threshold or percentile > 0.9:
                signal = TradeDirection.SHORT
                strength = min(1.0, abs(current) / self.extreme_threshold * 0.5)
                interpretation = 'extreme_long_crowded'
            
            # Very negative funding = shorts paying longs (crowded short) -> bullish contrarian
            elif current < -self.extreme_threshold or percentile < 0.1:
                signal = TradeDirection.LONG
                strength = min(1.0, abs(current) / self.extreme_threshold * 0.5)
                interpretation = 'extreme_short_crowded'
            
            # Moderately positive (trend following)
            elif current > avg * 2 and current > 0:
                signal = TradeDirection.LONG
                strength = 0.3
                interpretation = 'positive_momentum'
            
            # Moderately negative
            elif current < avg * 2 and current < 0:
                signal = TradeDirection.SHORT
                strength = 0.3
                interpretation = 'negative_momentum'
            
            return {
                'signal': signal,
                'strength': strength,
                'current_rate': float(current),
                'average_rate': float(avg),
                'percentile': float(percentile),
                'interpretation': interpretation,
                'extreme': abs(current) > self.extreme_threshold
            }
            
        except Exception as e:
            logger.error(f"Error analyzing funding rate: {e}")
            return self._default_analysis()
    
    def _default_analysis(self) -> Dict[str, any]:
        return {
            'signal': TradeDirection.NEUTRAL,
            'strength': 0.0,
            'current_rate': 0.0,
            'average_rate': 0.0,
            'percentile': 0.5,
            'interpretation': 'neutral',
            'extreme': False
        }
