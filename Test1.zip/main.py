#!/usr/bin/env python3
"""
AutoTrade Bot - Entry Point
"""
import asyncio
import argparse
from core.bot import TradingBot
from utils.logger import get_logger

logger = get_logger("main")


def parse_args():
    parser = argparse.ArgumentParser(description="AutoTrade Binance Futures Bot")
    parser.add_argument('--mode', choices=['paper', 'live'], default=None,
                       help='Trading mode override')
    parser.add_argument('--train', action='store_true',
                       help='Train MiroFish model and exit')
    return parser.parse_args()


async def main():
    args = parse_args()
    
    if args.mode:
        import os
        os.environ['AUTOTRADE_MODE'] = args.mode
        logger.info(f"Mode overridden to: {args.mode}")
    
    bot = TradingBot()
    
    if args.train:
        logger.info("Training mode selected")
        # Load historical data dan train
        # Implementation depends on data availability
        return
    
    await bot.run()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logger.info("Interrupted by user")
    except Exception as e:
        logger.critical(f"Fatal error: {e}", exc_info=True)
