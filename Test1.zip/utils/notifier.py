"""
Telegram & Discord notifier.
"""
import aiohttp
from typing import Optional
from config.credentials import CREDS
from config.settings import SETTINGS
from utils.logger import get_logger

logger = get_logger("utils.notifier")


class Notifier:
    def __init__(self):
        self.telegram_token = CREDS.telegram_bot_token
        self.telegram_chat = CREDS.telegram_chat_id
        self.discord_webhook = CREDS.discord_webhook_url
        self.enabled = any([self.telegram_token, self.discord_webhook])
    
    async def send_telegram(self, message: str):
        """Kirim notifikasi ke Telegram."""
        if not self.telegram_token or not self.telegram_chat:
            return
        
        try:
            url = f"https://api.telegram.org/bot{self.telegram_token}/sendMessage"
            payload = {
                'chat_id': self.telegram_chat,
                'text': message,
                'parse_mode': 'HTML'
            }
            
            async with aiohttp.ClientSession() as session:
                async with session.post(url, json=payload) as resp:
                    if resp.status != 200:
                        logger.error(f"Telegram error: {resp.status}")
                        
        except Exception as e:
            logger.error(f"Telegram send failed: {e}")
    
    async def send_discord(self, message: str):
        """Kirim notifikasi ke Discord via webhook."""
        if not self.discord_webhook:
            return
        
        try:
            payload = {'content': message}
            
            async with aiohttp.ClientSession() as session:
                async with session.post(self.discord_webhook, json=payload) as resp:
                    if resp.status not in [200, 204]:
                        logger.error(f"Discord error: {resp.status}")
                        
        except Exception as e:
            logger.error(f"Discord send failed: {e}")
    
    async def send_alert(self, message: str):
        """Kirim ke semua channels."""
        if not self.enabled:
            logger.debug(f"NOTIFICATION: {message[:100]}...")
            return
        
        await self.send_telegram(message)
        await self.send_discord(message)
