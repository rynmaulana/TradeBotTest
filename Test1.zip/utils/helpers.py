"""
Helper functions & decorators.
"""
import time
import functools
from typing import Callable, Any
from utils.logger import get_logger

logger = get_logger("utils.helpers")


def retry(max_attempts: int = 3, delay: float = 1.0, exceptions: tuple = (Exception,)):
    """Retry decorator dengan exponential backoff."""
    def decorator(func: Callable) -> Callable:
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            for attempt in range(1, max_attempts + 1):
                try:
                    return func(*args, **kwargs)
                except exceptions as e:
                    if attempt == max_attempts:
                        raise
                    wait = delay * (2 ** (attempt - 1))
                    logger.warning(f"Retry {attempt}/{max_attempts} for {func.__name__} in {wait}s: {e}")
                    time.sleep(wait)
            return None
        return wrapper
    return decorator


def format_price(price: float, precision: int = 2) -> str:
    """Format harga dengan precision yang sesuai."""
    if price >= 1000:
        return f"${price:,.{precision}f}"
    elif price >= 1:
        return f"${price:.2f}"
    else:
        return f"${price:.6f}"


def calculate_position_size(
    equity: float,
    risk_pct: float,
    entry: float,
    stop_loss: float,
    leverage: int = 1
) -> float:
    """
    Hitung position size berdasarkan risk amount.
    Risk Amount = |Entry - SL| * Quantity
    """
    risk_amount = equity * risk_pct
    price_risk = abs(entry - stop_loss)
    
    if price_risk == 0:
        return 0
    
    quantity = risk_amount / price_risk
    notional = quantity * entry
    max_notional = equity * leverage
    
    if notional > max_notional:
        quantity = max_notional / entry
    
    return quantity
