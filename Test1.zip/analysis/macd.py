"""
MACD indicator dengan divergence detection.
"""
import pandas as pd
import numpy as np
from typing import Dict, List, Tuple
from config.settings import TradeDirection
from utils.logger import get_logger

logger = get_logger("analysis.macd")


class MACDAnalyzer:
    def __init__(self, fast: int = 12, slow: int = 26, signal: int = 9):
        self.fast = fast
        self.slow = slow
        self.signal = signal
    
    def calculate(self, df: pd.DataFrame) -> pd.DataFrame:
        """Hitung MACD line, signal line, dan histogram."""
        df = df.copy()
        
        ema_fast = df['close'].ewm(span=self.fast, adjust=False).mean()
        ema_slow = df['close'].ewm(span=self.slow, adjust=False).mean()
        
        df['macd_line'] = ema_fast - ema_slow
        df['macd_signal'] = df['macd_line'].ewm(span=self.signal, adjust=False).mean()
        df['macd_histogram'] = df['macd_line'] - df['macd_signal']
        
        return df
    
    def detect_divergence(self, df: pd.DataFrame, lookback: int = 30) -> Dict[str, any]:
        """
        Deteksi bullish/bearish divergence antara price dan MACD.
        Bullish divergence: Price lower low, MACD higher low.
        Bearish divergence: Price higher high, MACD lower high.
        """
        if len(df) < lookback + 5:
            return {'divergence': 'none', 'strength': 0.0}
        
        window = df.iloc[-lookback:].copy()
        price = window['close'].values
        macd = window['macd_line'].values
        
        # Simplified divergence detection using local extrema
        # Find last 2 significant lows/highs
        def find_extrema(arr: np.ndarray, order: int = 3):
            from scipy.signal import argrelextrema
            if len(arr) < order * 2 + 1:
                return [], []
            minima = argrelextrema(arr, np.less, order=order)[0]
            maxima = argrelextrema(arr, np.greater, order=order)[0]
            return minima, maxima
        
        price_minima, price_maxima = find_extrema(price)
        macd_minima, macd_maxima = find_extrema(macd)
        
        divergence = 'none'
        strength = 0.0
        
        # Check bullish divergence (price LL, MACD HL)
        if len(price_minima) >= 2 and len(macd_minima) >= 2:
            p_low1, p_low2 = price[price_minima[-2]], price[price_minima[-1]]
            m_low1, m_low2 = macd[macd_minima[-2]], macd[macd_minima[-1]]
            
            if p_low2 < p_low1 and m_low2 > m_low1:
                divergence = 'bullish'
                strength = 0.8
        
        # Check bearish divergence (price HH, MACD LH)
        if len(price_maxima) >= 2 and len(macd_maxima) >= 2:
            p_high1, p_high2 = price[price_maxima[-2]], price[price_maxima[-1]]
            m_high1, m_high2 = macd[macd_maxima[-2]], macd[macd_maxima[-1]]
            
            if p_high2 > p_high1 and m_high2 < m_high1:
                divergence = 'bearish'
                strength = 0.8
        
        return {'divergence': divergence, 'strength': strength}
    
    def generate_signal(self, df: pd.DataFrame) -> Dict[str, any]:
        """Generate trading signal dari MACD."""
        if len(df) < 2:
            return {'signal': TradeDirection.NEUTRAL, 'strength': 0.0, 'details': {}}
        
        curr = df.iloc[-1]
        prev = df.iloc[-2]
        
        macd_line = curr['macd_line']
        signal_line = curr['macd_signal']
        histogram = curr['macd_histogram']
        prev_histogram = prev['macd_histogram']
        
        signal = TradeDirection.NEUTRAL
        strength = 0.0
        
        # MACD line crosses above signal line -> bullish
        if prev['macd_line'] <= prev['macd_signal'] and macd_line > signal_line:
            signal = TradeDirection.LONG
            strength = 0.6
        
        # MACD line crosses below signal line -> bearish
        elif prev['macd_line'] >= prev['macd_signal'] and macd_line < signal_line:
            signal = TradeDirection.SHORT
            strength = 0.6
        
        # Histogram momentum
        if histogram > 0 and histogram > prev_histogram:
            strength = min(1.0, strength + 0.1)  # Increasing bullish momentum
        elif histogram < 0 and histogram < prev_histogram:
            strength = min(1.0, strength + 0.1)  # Increasing bearish momentum
        
        # Divergence boost
        div = self.detect_divergence(df)
        if div['divergence'] == 'bullish' and signal == TradeDirection.LONG:
            strength = min(1.0, strength + 0.15)
        elif div['divergence'] == 'bearish' and signal == TradeDirection.SHORT:
            strength = min(1.0, strength + 0.15)
        
        return {
            'signal': signal,
            'strength': strength,
            'macd_line': macd_line,
            'signal_line': signal_line,
            'histogram': histogram,
            'divergence': div
        }
