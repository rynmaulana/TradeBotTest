"""
Relative Strength Index (RSI) dengan overbought/oversold zones dan divergence.
"""
import pandas as pd
import numpy as np
from typing import Dict
from config.settings import TradeDirection
from utils.logger import get_logger

logger = get_logger("analysis.rsi")


class RSIAnalyzer:
    def __init__(self, period: int = 14, overbought: float = 70, oversold: float = 30):
        self.period = period
        self.overbought = overbought
        self.oversold = oversold
    
    def calculate(self, df: pd.DataFrame) -> pd.DataFrame:
        """Hitung RSI."""
        df = df.copy()
        delta = df['close'].diff()
        
        gain = delta.where(delta > 0, 0.0)
        loss = (-delta.where(delta < 0, 0.0))
        
        avg_gain = gain.ewm(alpha=1/self.period, min_periods=self.period).mean()
        avg_loss = loss.ewm(alpha=1/self.period, min_periods=self.period).mean()
        
        rs = avg_gain / avg_loss
        df['rsi'] = 100 - (100 / (1 + rs))
        
        # RSI-based moving average
        df['rsi_ma'] = df['rsi'].ewm(span=9, adjust=False).mean()
        
        return df
    
    def generate_signal(self, df: pd.DataFrame) -> Dict[str, any]:
        """Generate signal dari RSI."""
        if len(df) < 2 or 'rsi' not in df.columns:
            return {'signal': TradeDirection.NEUTRAL, 'strength': 0.0, 'rsi': 50}
        
        curr = df.iloc[-1]
        prev = df.iloc[-2]
        rsi = curr['rsi']
        
        signal = TradeDirection.NEUTRAL
        strength = 0.0
        
        # Oversold bounce (buy)
        if rsi < self.oversold:
            signal = TradeDirection.LONG
            strength = (self.oversold - rsi) / self.oversold * 0.5  # More oversold = stronger signal
        
        # Overbought reversal (sell)
        elif rsi > self.overbought:
            signal = TradeDirection.SHORT
            strength = (rsi - self.overbought) / (100 - self.overbought) * 0.5
        
        # RSI crosses above 50 (bullish momentum)
        elif prev['rsi'] <= 50 and rsi > 50:
            signal = TradeDirection.LONG
            strength = 0.3
        
        # RSI crosses below 50 (bearish momentum)
        elif prev['rsi'] >= 50 and rsi < 50:
            signal = TradeDirection.SHORT
            strength = 0.3
        
        # Divergence detection (simplified)
        div = self._detect_divergence(df)
        if div == 'bullish' and signal in [TradeDirection.LONG, TradeDirection.NEUTRAL]:
            strength = min(1.0, strength + 0.2)
            if signal == TradeDirection.NEUTRAL:
                signal = TradeDirection.LONG
        elif div == 'bearish' and signal in [TradeDirection.SHORT, TradeDirection.NEUTRAL]:
            strength = min(1.0, strength + 0.2)
            if signal == TradeDirection.NEUTRAL:
                signal = TradeDirection.SHORT
        
        return {
            'signal': signal,
            'strength': min(1.0, strength),
            'rsi': rsi,
            'rsi_ma': curr.get('rsi_ma'),
            'divergence': div
        }
    
    def _detect_divergence(self, df: pd.DataFrame, lookback: int = 20) -> str:
        """Simplified RSI divergence."""
        if len(df) < lookback:
            return 'none'
        
        window = df.iloc[-lookback:]
        price = window['close'].values
        rsi_vals = window['rsi'].values
        
        # Check if price made lower low but RSI made higher low
        p_low = np.argmin(price)
        r_low = np.argmin(rsi_vals)
        
        if abs(p_low - r_low) <= 3:
            if price[p_low] < price[0] and rsi_vals[r_low] > rsi_vals[0]:
                return 'bullish'
        
        # Check if price made higher high but RSI made lower high
        p_high = np.argmax(price)
        r_high = np.argmax(rsi_vals)
        
        if abs(p_high - r_high) <= 3:
            if price[p_high] > price[0] and rsi_vals[r_high] < rsi_vals[0]:
                return 'bearish'
        
        return 'none'
