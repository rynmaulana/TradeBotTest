"""
Exponential Moving Average (EMA) calculations dengan multi-period.
"""
import pandas as pd
import numpy as np
from typing import Dict, Tuple
from config.settings import TradeDirection
from utils.logger import get_logger

logger = get_logger("analysis.ema")


class EMAAnalyzer:
    PERIODS = [9, 21, 50, 200]
    
    def __init__(self, periods: list = None):
        self.periods = periods or self.PERIODS
    
    def calculate(self, df: pd.DataFrame) -> pd.DataFrame:
        """Hitung EMA untuk semua period."""
        df = df.copy()
        for period in self.periods:
            df[f'ema_{period}'] = df['close'].ewm(span=period, adjust=False).mean()
        return df
    
    def detect_crossover(self, df: pd.DataFrame) -> Dict[str, any]:
        """
        Deteksi Golden Cross & Death Cross antar EMA.
        Returns: {'signal': direction, 'strength': 0-1, 'cross_type': str}
        """
        if len(df) < 2:
            return {'signal': TradeDirection.NEUTRAL, 'strength': 0.0, 'cross_type': 'none'}
        
        curr = df.iloc[-1]
        prev = df.iloc[-2]
        
        # EMA 9 vs EMA 21 (short-term)
        ema9_curr = curr.get('ema_9')
        ema21_curr = curr.get('ema_21')
        ema9_prev = prev.get('ema_9')
        ema21_prev = prev.get('ema_21')
        
        if pd.isna(ema9_curr) or pd.isna(ema21_curr):
            return {'signal': TradeDirection.NEUTRAL, 'strength': 0.0, 'cross_type': 'none'}
        
        signal = TradeDirection.NEUTRAL
        strength = 0.0
        cross_type = 'none'
        
        # Golden cross: EMA9 cross above EMA21
        if ema9_prev <= ema21_prev and ema9_curr > ema21_curr:
            signal = TradeDirection.LONG
            cross_type = 'golden_cross_short'
            strength = 0.7
        
        # Death cross: EMA9 cross below EMA21
        elif ema9_prev >= ema21_prev and ema9_curr < ema21_curr:
            signal = TradeDirection.SHORT
            cross_type = 'death_cross_short'
            strength = 0.7
        
        # Trend bias dari EMA 50 vs 200
        ema50 = curr.get('ema_50')
        ema200 = curr.get('ema_200')
        if not pd.isna(ema50) and not pd.isna(ema200):
            if ema50 > ema200 and signal == TradeDirection.LONG:
                strength = min(1.0, strength + 0.2)  # Confirms uptrend
            elif ema50 < ema200 and signal == TradeDirection.SHORT:
                strength = min(1.0, strength + 0.2)  # Confirms downtrend
        
        return {
            'signal': signal,
            'strength': strength,
            'cross_type': cross_type,
            'ema_values': {f'ema_{p}': curr.get(f'ema_{p}') for p in self.periods}
        }
    
    def get_trend_bias(self, df: pd.DataFrame) -> TradeDirection:
        """Determine trend bias berdasarkan EMA stack."""
        if len(df) == 0:
            return TradeDirection.NEUTRAL
        
        last = df.iloc[-1]
        close = last['close']
        
        # Bullish alignment: price > ema9 > ema21 > ema50 > ema200
        if (close > last.get('ema_9', 0) > last.get('ema_21', 0) > 
            last.get('ema_50', 0) > last.get('ema_200', 0)):
            return TradeDirection.LONG
        
        # Bearish alignment
        if (close < last.get('ema_9', float('inf')) < last.get('ema_21', float('inf')) < 
            last.get('ema_50', float('inf')) < last.get('ema_200', float('inf'))):
            return TradeDirection.SHORT
        
        return TradeDirection.NEUTRAL
