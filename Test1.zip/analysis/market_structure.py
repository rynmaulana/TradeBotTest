"""
Market Structure Analysis: HH/HL/LH/LL, BOS, CHoCH, Support/Resistance.
"""
import pandas as pd
import numpy as np
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass
from enum import Enum
from config.settings import TradeDirection
from utils.logger import get_logger

logger = get_logger("analysis.market_structure")


class StructureType(Enum):
    HH = "Higher High"
    HL = "Higher Low"
    LH = "Lower High"
    LL = "Lower Low"
    BOS = "Break of Structure"
    CHOCH = "Change of Character"


@dataclass
class SwingPoint:
    index: int
    timestamp: pd.Timestamp
    price: float
    type: str  # 'high' or 'low'


class MarketStructureAnalyzer:
    def __init__(self, swing_lookback: int = 5):
        self.swing_lookback = swing_lookback
        self.swing_points: List[SwingPoint] = []
        self.support_zones: List[Tuple[float, float]] = []
        self.resistance_zones: List[Tuple[float, float]] = []
    
    def find_swing_points(self, df: pd.DataFrame) -> List[SwingPoint]:
        """Identifikasi swing highs dan swing lows."""
        highs = df['high'].values
        lows = df['low'].values
        timestamps = df.index
        
        swing_highs = []
        swing_lows = []
        
        for i in range(self.swing_lookback, len(df) - self.swing_lookback):
            # Swing high: higher than neighbors
            if all(highs[i] > highs[i-j] for j in range(1, self.swing_lookback+1)) and \
               all(highs[i] > highs[i+j] for j in range(1, self.swing_lookback+1)):
                swing_highs.append(SwingPoint(i, timestamps[i], highs[i], 'high'))
            
            # Swing low: lower than neighbors
            if all(lows[i] < lows[i-j] for j in range(1, self.swing_lookback+1)) and \
               all(lows[i] < lows[i+j] for j in range(1, self.swing_lookback+1)):
                swing_lows.append(SwingPoint(i, timestamps[i], lows[i], 'low'))
        
        # Combine and sort by index
        all_swings = swing_highs + swing_lows
        all_swings.sort(key=lambda x: x.index)
        self.swing_points = all_swings
        return all_swings
    
    def classify_structure(self, df: pd.DataFrame) -> Dict[str, any]:
        """
        Klasifikasi market structure: Uptrend (HH, HL), Downtrend (LH, LL), 
        BOS (Break of Structure), CHoCH (Change of Character).
        """
        swings = self.find_swing_points(df)
        if len(swings) < 4:
            return {
                'trend': TradeDirection.NEUTRAL,
                'last_structure': None,
                'bos': False,
                'choch': False,
                'swing_count': len(swings)
            }
        
        # Analyze last 4 swings for structure
        recent = swings[-4:]
        structures = []
        
        for i in range(1, len(recent)):
            prev = recent[i-1]
            curr = recent[i]
            
            if prev.type == 'high' and curr.type == 'high':
                if curr.price > prev.price:
                    structures.append(StructureType.HH)
                else:
                    structures.append(StructureType.LH)
            
            elif prev.type == 'low' and curr.type == 'low':
                if curr.price > prev.price:
                    structures.append(StructureType.HL)
                else:
                    structures.append(StructureType.LL)
        
        # Determine trend
        trend = TradeDirection.NEUTRAL
        if structures.count(StructureType.HH) > structures.count(StructureType.LH):
            trend = TradeDirection.LONG
        elif structures.count(StructureType.LL) > structures.count(StructureType.HL):
            trend = TradeDirection.SHORT
        
        # Detect BOS (Break of Structure)
        # In uptrend: price breaks above previous high
        # In downtrend: price breaks below previous low
        bos = False
        choch = False
        
        if len(recent) >= 3:
            last_two_highs = [s for s in recent if s.type == 'high'][-2:]
            last_two_lows = [s for s in recent if s.type == 'low'][-2:]
            
            current_price = df['close'].iloc[-1]
            
            if trend == TradeDirection.LONG and len(last_two_highs) == 2:
                if current_price > last_two_highs[0].price:
                    bos = True
            
            if trend == TradeDirection.SHORT and len(last_two_lows) == 2:
                if current_price < last_two_lows[0].price:
                    bos = True
        
        # Detect CHoCH (Change of Character)
        # Uptrend to downtrend: price breaks below last higher low
        # Downtrend to uptrend: price breaks above last lower high
        if len(last_two_lows) == 2 and len(last_two_highs) == 2:
            if trend == TradeDirection.LONG:
                if current_price < last_two_lows[-1].price:
                    choch = True
                    trend = TradeDirection.SHORT
            elif trend == TradeDirection.SHORT:
                if current_price > last_two_highs[-1].price:
                    choch = True
                    trend = TradeDirection.LONG
        
        return {
            'trend': trend,
            'structures': [s.value for s in structures],
            'bos': bos,
            'choch': choch,
            'swing_points': [(s.type, float(s.price)) for s in recent],
            'last_structure': structures[-1].value if structures else None
        }
    
    def find_support_resistance(self, df: pd.DataFrame, zone_width_pct: float = 0.005) -> Dict[str, List]:
        """Identifikasi Support & Resistance zones berdasarkan swing points."""
        swings = self.find_swing_points(df)
        if not swings:
            return {'support': [], 'resistance': []}
        
        highs = [s.price for s in swings if s.type == 'high']
        lows = [s.price for s in swings if s.type == 'low']
        
        # Cluster nearby levels
        def cluster_levels(levels: List[float], width_pct: float) -> List[Tuple[float, float]]:
            if not levels:
                return []
            levels = sorted(levels)
            clusters = []
            current_cluster = [levels[0]]
            
            for level in levels[1:]:
                if (level - current_cluster[0]) / current_cluster[0] < width_pct:
                    current_cluster.append(level)
                else:
                    avg = sum(current_cluster) / len(current_cluster)
                    clusters.append((min(current_cluster), max(current_cluster), avg))
                    current_cluster = [level]
            
            if current_cluster:
                avg = sum(current_cluster) / len(current_cluster)
                clusters.append((min(current_cluster), max(current_cluster), avg))
            
            return clusters
        
        self.resistance_zones = [(c[0], c[1]) for c in cluster_levels(highs, zone_width_pct)]
        self.support_zones = [(c[0], c[1]) for c in cluster_levels(lows, zone_width_pct)]
        
        return {
            'support': self.support_zones,
            'resistance': self.resistance_zones
        }
    
    def generate_signal(self, df: pd.DataFrame) -> Dict[str, any]:
        """Generate comprehensive market structure signal."""
        structure = self.classify_structure(df)
        sr = self.find_support_resistance(df)
        
        signal = TradeDirection.NEUTRAL
        strength = 0.0
        current_price = df['close'].iloc[-1]
        
        # Signal dari trend structure
        if structure['trend'] == TradeDirection.LONG:
            signal = TradeDirection.LONG
            strength = 0.5
            if structure['bos']:
                strength = 0.8  # Strong confirmation
        elif structure['trend'] == TradeDirection.SHORT:
            signal = TradeDirection.SHORT
            strength = 0.5
            if structure['bos']:
                strength = 0.8
        
        # CHoCH adalah early reversal signal
        if structure['choch']:
            # Reverse signal
            signal = TradeDirection.SHORT if signal == TradeDirection.LONG else TradeDirection.LONG
            strength = 0.7
        
        # Check proximity to S/R zones
        for zone in sr['support']:
            if zone[0] <= current_price <= zone[1]:
                if signal == TradeDirection.LONG:
                    strength = min(1.0, strength + 0.1)  # Bounce from support
                break
        
        for zone in sr['resistance']:
            if zone[0] <= current_price <= zone[1]:
                if signal == TradeDirection.SHORT:
                    strength = min(1.0, strength + 0.1)  # Rejection from resistance
                break
        
        return {
            'signal': signal,
            'strength': strength,
            'structure': structure,
            'support_resistance': sr
        }
