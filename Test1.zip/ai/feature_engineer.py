"""
Feature engineering pipeline untuk ML model MiroFish.
"""
import pandas as pd
import numpy as np
from typing import List, Tuple
from utils.logger import get_logger

logger = get_logger("ai.features")


class FeatureEngineer:
    def __init__(self):
        self.feature_columns: List[str] = []
    
    def create_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """Generate comprehensive feature set."""
        df = df.copy()
        
        # Price-based features
        df['returns'] = df['close'].pct_change()
        df['log_returns'] = np.log(df['close'] / df['close'].shift(1))
        
        # Volatility features
        for window in [5, 10, 20, 50]:
            df[f'volatility_{window}'] = df['returns'].rolling(window).std()
            df[f'atr_{window}'] = self._calculate_atr(df, window)
        
        # Moving average features
        for window in [9, 21, 50, 200]:
            df[f'sma_{window}'] = df['close'].rolling(window).mean()
            df[f'dist_sma_{window}'] = (df['close'] - df[f'sma_{window}']) / df[f'sma_{window}']
        
        # Momentum features
        df['momentum_10'] = df['close'] / df['close'].shift(10) - 1
        df['momentum_30'] = df['close'] / df['close'].shift(30) - 1
        
        # Volume features
        df['volume_sma_20'] = df['volume'].rolling(20).mean()
        df['volume_ratio'] = df['volume'] / df['volume_sma_20']
        df['obv'] = self._calculate_obv(df)
        
        # Range features
        df['high_low_range'] = (df['high'] - df['low']) / df['close']
        df['body_ratio'] = abs(df['close'] - df['open']) / (df['high'] - df['low'] + 1e-10)
        
        # Lag features
        for lag in [1, 2, 3, 5]:
            df[f'returns_lag_{lag}'] = df['returns'].shift(lag)
        
        # Target: future returns (classification)
        future_return = df['close'].shift(-5) / df['close'] - 1
        df['target'] = np.where(future_return > 0.005, 1, 
                       np.where(future_return < -0.005, -1, 0))
        
        # Drop NaN
        df.dropna(inplace=True)
        
        self.feature_columns = [c for c in df.columns if c not in 
                               ['open', 'high', 'low', 'close', 'volume', 'target']]
        
        return df
    
    def _calculate_atr(self, df: pd.DataFrame, period: int = 14) -> pd.Series:
        """Average True Range."""
        high_low = df['high'] - df['low']
        high_close = np.abs(df['high'] - df['close'].shift())
        low_close = np.abs(df['low'] - df['close'].shift())
        tr = pd.concat([high_low, high_close, low_close], axis=1).max(axis=1)
        return tr.rolling(period).mean()
    
    def _calculate_obv(self, df: pd.DataFrame) -> pd.Series:
        """On-Balance Volume."""
        obv = [0]
        for i in range(1, len(df)):
            if df['close'].iloc[i] > df['close'].iloc[i-1]:
                obv.append(obv[-1] + df['volume'].iloc[i])
            elif df['close'].iloc[i] < df['close'].iloc[i-1]:
                obv.append(obv[-1] - df['volume'].iloc[i])
            else:
                obv.append(obv[-1])
        return pd.Series(obv, index=df.index)
    
    def prepare_train_data(self, df: pd.DataFrame) -> Tuple[pd.DataFrame, pd.Series]:
        """Prepare X, y untuk training."""
        df = self.create_features(df)
        X = df[self.feature_columns]
        y = df['target']
        return X, y
