"""
Claude AI Integration untuk advanced market reasoning.
"""
import os
import json
import aiohttp
from typing import Dict, List
from config.credentials import CREDS
from config.settings import TradeDirection
from utils.logger import get_logger

logger = get_logger("ai.claude")


class ClaudeIntegration:
    def __init__(self):
        self.api_key = CREDS.anthropic_api_key
        self.base_url = "https://api.anthropic.com/v1/messages"
        self.model = "claude-opus-4-5-20251101"  # Sesuai gambar: claude-opus-4-5
        self.enabled = bool(self.api_key)
    
    async def analyze_market(
        self,
        symbol: str,
        technical_summary: str,
        onchain_summary: str,
        sentiment_summary: str,
        recent_price_action: List[Dict]
    ) -> Dict[str, any]:
        """
        Kirim market context ke Claude untuk reasoning lanjutan.
        """
        if not self.enabled:
            return {
                'signal': TradeDirection.NEUTRAL,
                'confidence': 0.0,
                'reasoning': 'Claude API key not configured',
                'status': 'disabled'
            }
        
        prompt = self._build_prompt(symbol, technical_summary, onchain_summary, sentiment_summary, recent_price_action)
        
        try:
            async with aiohttp.ClientSession() as session:
                headers = {
                    "x-api-key": self.api_key,
                    "anthropic-version": "2023-06-01",
                    "content-type": "application/json"
                }
                
                payload = {
                    "model": self.model,
                    "max_tokens": 1024,
                    "messages": [
                        {
                            "role": "user",
                            "content": prompt
                        }
                    ]
                }
                
                async with session.post(self.base_url, headers=headers, json=payload) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        content = data['content'][0]['text']
                        return self._parse_claude_response(content)
                    else:
                        error_text = await resp.text()
                        logger.error(f"Claude API error {resp.status}: {error_text}")
                        return {
                            'signal': TradeDirection.NEUTRAL,
                            'confidence': 0.0,
                            'reasoning': f'API Error: {resp.status}',
                            'status': 'error'
                        }
                        
        except Exception as e:
            logger.error(f"Claude integration error: {e}")
            return {
                'signal': TradeDirection.NEUTRAL,
                'confidence': 0.0,
                'reasoning': str(e),
                'status': 'error'
            }
    
    def _build_prompt(
        self,
        symbol: str,
        tech: str,
        onchain: str,
        sentiment: str,
        price_action: List[Dict]
    ) -> str:
        """Build structured prompt untuk Claude."""
        prices = json.dumps(price_action[-5:]) if price_action else "N/A"
        
        prompt = f"""You are an elite crypto trading analyst. Analyze the following market data for {symbol} and provide a structured trading decision.

## Technical Analysis
{tech}

## On-Chain Data
{onchain}

## Market Sentiment
{sentiment}

## Recent Price Action
{prices}

## Instructions
Respond ONLY in this exact JSON format:
{{
    "direction": "BULLISH" | "BEARISH" | "NEUTRAL",
    "confidence": 0.0 to 1.0,
    "reasoning": "concise explanation max 200 chars",
    "key_levels": {{"support": float, "resistance": float}},
    "risk_assessment": "LOW" | "MEDIUM" | "HIGH"
}}

Do not include any other text outside the JSON."""
        return prompt
    
    def _parse_claude_response(self, text: str) -> Dict[str, any]:
        """Parse JSON response dari Claude."""
        try:
            # Extract JSON dari response text
            text = text.strip()
            if text.startswith("```json"):
                text = text[7:]
            if text.endswith("```"):
                text = text[:-3]
            text = text.strip()
            
            result = json.loads(text)
            
            direction_map = {
                "BULLISH": TradeDirection.LONG,
                "BEARISH": TradeDirection.SHORT,
                "NEUTRAL": TradeDirection.NEUTRAL
            }
            
            return {
                'signal': direction_map.get(result.get('direction', 'NEUTRAL'), TradeDirection.NEUTRAL),
                'confidence': float(result.get('confidence', 0)),
                'reasoning': result.get('reasoning', ''),
                'key_levels': result.get('key_levels', {}),
                'risk_assessment': result.get('risk_assessment', 'MEDIUM'),
                'status': 'success'
            }
            
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse Claude response: {e}\nText: {text[:500]}")
            return {
                'signal': TradeDirection.NEUTRAL,
                'confidence': 0.0,
                'reasoning': 'Parse error',
                'status': 'parse_error'
            }
