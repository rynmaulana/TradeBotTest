"""
Sentiment analysis untuk news & social media.
"""
import aiohttp
import pandas as pd
from typing import Dict, List
from datetime import datetime
from config.settings import TradeDirection
from utils.logger import get_logger

logger = get_logger("ai.sentiment")


class SentimentAnalyzer:
    def __init__(self):
        # Fallback ke keyword-based jika tidak ada API berbayar
        self.bullish_keywords = [
            'bullish', 'surge', 'rally', 'moon', 'breakout', 'adoption', 
            'institutional', 'accumulation', ' ATH', 'all time high'
        ]
        self.bearish_keywords = [
            'bearish', 'crash', 'dump', 'collapse', 'regulation', 'ban',
            'hack', 'liquidation', 'death cross', 'support broken'
        ]
        self.fear_greed_url = "https://api.alternative.me/fng/?limit=2"
    
    async def fetch_fear_greed_index(self) -> Dict[str, any]:
        """Fetch Fear & Greed Index."""
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(self.fear_greed_url) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        values = data.get('data', [])
                        if values:
                            latest = values[0]
                            return {
                                'value': int(latest['value']),
                                'classification': latest['value_classification'],
                                'timestamp': latest['timestamp']
                            }
                    return {'value': 50, 'classification': 'neutral', 'timestamp': None}
        except Exception as e:
            logger.error(f"Error fetching F&G: {e}")
            return {'value': 50, 'classification': 'neutral', 'timestamp': None}
    
    def analyze_text_sentiment(self, texts: List[str]) -> Dict[str, any]:
        """Analisis sederhana berbasis keyword (placeholder untuk NLP model)."""
        if not texts:
            return {'sentiment': 'neutral', 'score': 0.0}
        
        bullish_count = sum(1 for text in texts for kw in self.bullish_keywords if kw.lower() in text.lower())
        bearish_count = sum(1 for text in texts for kw in self.bearish_keywords if kw.lower() in text.lower())
        
        total = bullish_count + bearish_count
        if total == 0:
            return {'sentiment': 'neutral', 'score': 0.0, 'details': {'bullish': 0, 'bearish': 0}}
        
        score = (bullish_count - bearish_count) / total
        
        sentiment = 'neutral'
        if score > 0.2:
            sentiment = 'bullish'
        elif score < -0.2:
            sentiment = 'bearish'
        
        return {
            'sentiment': sentiment,
            'score': float(score),
            'details': {'bullish': bullish_count, 'bearish': bearish_count, 'total_mentions': total}
        }
    
    async def generate_signal(self, news_texts: List[str] = None) -> Dict[str, any]:
        """Generate sentiment-based signal."""
        fg = await self.fetch_fear_greed_index()
        
        signal = TradeDirection.NEUTRAL
        strength = 0.0
        
        # Fear & Greed interpretation (contrarian)
        fg_value = fg['value']
        if fg_value < 20:  # Extreme fear -> bullish
            signal = TradeDirection.LONG
            strength = (20 - fg_value) / 20 * 0.5
        elif fg_value > 80:  # Extreme greed -> bearish
            signal = TradeDirection.SHORT
            strength = (fg_value - 80) / 20 * 0.5
        
        # News sentiment
        if news_texts:
            text_sent = self.analyze_text_sentiment(news_texts)
            if text_sent['sentiment'] == 'bullish':
                if signal == TradeDirection.LONG:
                    strength = min(1.0, strength + abs(text_sent['score']) * 0.3)
                elif signal == TradeDirection.NEUTRAL:
                    signal = TradeDirection.LONG
                    strength = abs(text_sent['score']) * 0.3
            elif text_sent['sentiment'] == 'bearish':
                if signal == TradeDirection.SHORT:
                    strength = min(1.0, strength + abs(text_sent['score']) * 0.3)
                elif signal == TradeDirection.NEUTRAL:
                    signal = TradeDirection.SHORT
                    strength = abs(text_sent['score']) * 0.3
        
        return {
            'signal': signal,
            'strength': float(strength),
            'fear_greed': fg,
            'text_sentiment': self.analyze_text_sentiment(news_texts or [])
        }
