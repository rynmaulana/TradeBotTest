"""
MiroFish: Core ML model menggunakan ensemble RandomForest + GradientBoosting.
"""
import os
import joblib
import pandas as pd
import numpy as np
from typing import Dict, Tuple, Optional
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier, VotingClassifier
from sklearn.model_selection import TimeSeriesSplit
from sklearn.metrics import accuracy_score, classification_report
from sklearn.preprocessing import StandardScaler
from config.settings import SETTINGS, TradeDirection
from ai.feature_engineer import FeatureEngineer
from utils.logger import get_logger

logger = get_logger("ai.mirofish")


class MiroFishModel:
    def __init__(self, model_dir: str = None):
        self.model_dir = model_dir or SETTINGS.models_dir
        os.makedirs(self.model_dir, exist_ok=True)
        
        self.feature_engineer = FeatureEngineer()
        self.scaler = StandardScaler()
        self.model: Optional[VotingClassifier] = None
        self.is_trained = False
        self.model_path = os.path.join(self.model_dir, "mirofish_ensemble.pkl")
        self.scaler_path = os.path.join(self.model_dir, "scaler.pkl")
    
    def build_model(self) -> VotingClassifier:
        """Build ensemble model: RF + GB dengan soft voting."""
        rf = RandomForestClassifier(
            n_estimators=200,
            max_depth=10,
            min_samples_split=5,
            random_state=42,
            n_jobs=-1
        )
        
        gb = GradientBoostingClassifier(
            n_estimators=150,
            learning_rate=0.05,
            max_depth=5,
            min_samples_split=5,
            random_state=42
        )
        
        ensemble = VotingClassifier(
            estimators=[('rf', rf), ('gb', gb)],
            voting='soft'
        )
        
        return ensemble
    
    def train(self, df: pd.DataFrame) -> Dict[str, float]:
        """Train model dengan walk-forward validation."""
        logger.info("MiroFish: Starting training pipeline...")
        
        X, y = self.feature_engineer.prepare_train_data(df)
        if len(X) < 100:
            logger.warning("Insufficient data for training")
            return {'accuracy': 0.0, 'status': 'insufficient_data'}
        
        # Scale features
        X_scaled = self.scaler.fit_transform(X)
        X_scaled = pd.DataFrame(X_scaled, index=X.index, columns=X.columns)
        
        # Time series split untuk validasi
        tscv = TimeSeriesSplit(n_splits=5)
        accuracies = []
        
        self.model = self.build_model()
        
        for fold, (train_idx, val_idx) in enumerate(tscv.split(X_scaled)):
            X_train, X_val = X_scaled.iloc[train_idx], X_scaled.iloc[val_idx]
            y_train, y_val = y.iloc[train_idx], y.iloc[val_idx]
            
            self.model.fit(X_train, y_train)
            preds = self.model.predict(X_val)
            acc = accuracy_score(y_val, preds)
            accuracies.append(acc)
            logger.info(f"Fold {fold+1} accuracy: {acc:.3f}")
        
        # Final training on all data
        self.model.fit(X_scaled, y)
        self.is_trained = True
        
        # Save model
        joblib.dump(self.model, self.model_path)
        joblib.dump(self.scaler, self.scaler_path)
        logger.info(f"Model saved to {self.model_path}")
        
        avg_acc = np.mean(accuracies)
        return {
            'accuracy': float(avg_acc),
            'fold_accuracies': accuracies,
            'status': 'trained'
        }
    
    def load_model(self) -> bool:
        """Load pre-trained model."""
        try:
            if os.path.exists(self.model_path) and os.path.exists(self.scaler_path):
                self.model = joblib.load(self.model_path)
                self.scaler = joblib.load(self.scaler_path)
                self.is_trained = True
                logger.info("MiroFish model loaded successfully")
                return True
            return False
        except Exception as e:
            logger.error(f"Error loading model: {e}")
            return False
    
    def predict(self, df: pd.DataFrame) -> Dict[str, any]:
        """Generate prediction untuk candle terakhir."""
        if not self.is_trained and not self.load_model():
            return {
                'signal': TradeDirection.NEUTRAL,
                'confidence': 0.0,
                'probabilities': {},
                'status': 'not_trained'
            }
        
        try:
            # Prepare features
            df_features = self.feature_engineer.create_features(df)
            if len(df_features) == 0:
                return {'signal': TradeDirection.NEUTRAL, 'confidence': 0.0, 'status': 'no_features'}
            
            X = df_features[self.feature_engineer.feature_columns].iloc[-1:]
            X_scaled = self.scaler.transform(X)
            
            # Predict probabilities
            proba = self.model.predict_proba(X_scaled)[0]
            classes = self.model.classes_
            
            # Map classes: -1 (down), 0 (neutral), 1 (up)
            prob_dict = {int(c): float(p) for c, p in zip(classes, proba)}
            
            up_prob = prob_dict.get(1, 0)
            down_prob = prob_dict.get(-1, 0)
            neutral_prob = prob_dict.get(0, 0)
            
            # Determine signal
            signal = TradeDirection.NEUTRAL
            confidence = 0.0
            
            if up_prob > down_prob and up_prob > neutral_prob:
                signal = TradeDirection.LONG
                confidence = up_prob
            elif down_prob > up_prob and down_prob > neutral_prob:
                signal = TradeDirection.SHORT
                confidence = down_prob
            
            return {
                'signal': signal,
                'confidence': float(confidence),
                'probabilities': prob_dict,
                'status': 'success'
            }
            
        except Exception as e:
            logger.error(f"Prediction error: {e}")
            return {
                'signal': TradeDirection.NEUTRAL,
                'confidence': 0.0,
                'status': f'error: {str(e)}'
            }
