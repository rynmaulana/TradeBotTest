"""
Binance Futures Executor: order execution & position management.
"""
import asyncio
from typing import Dict, Optional
from dataclasses import dataclass
from config.settings import SETTINGS, SymbolConfig, TradeDirection
from data.fetcher import DataFetcher
from utils.logger import get_logger

logger = get_logger("core.executor")


@dataclass
class OrderResult:
    success: bool
    order_id: Optional[str]
    filled_price: Optional[float]
    filled_qty: Optional[float]
    fee: Optional[float]
    error: Optional[str] = None


class Executor:
    def __init__(self):
        self.fetcher = DataFetcher()
        self.positions: Dict[str, Dict] = {}  # symbol -> position info
    
    async def initialize(self):
        await self.fetcher.initialize()
    
    async def set_leverage(self, symbol: str, leverage: int):
        """Set leverage untuk symbol."""
        try:
            # CCXT format: symbol harus format standar
            ccxt_symbol = symbol if '/' in symbol else symbol.replace('USDT', '/USDT')
            await self.fetcher.exchange.set_leverage(leverage, ccxt_symbol)
            logger.info(f"Leverage set to {leverage}x for {symbol}")
        except Exception as e:
            logger.error(f"Error setting leverage: {e}")
    
    async def place_market_order(
        self,
        symbol_config: SymbolConfig,
        direction: TradeDirection,
        size_usd: float,
        stop_loss: Optional[float] = None,
        take_profit: Optional[float] = None
    ) -> OrderResult:
        """Place market order dengan TP/SL."""
        try:
            symbol = symbol_config.symbol
            ccxt_symbol = symbol if '/' in symbol else symbol.replace('USDT', '/USDT')
            
            # Set leverage dulu
            await self.set_leverage(symbol, symbol_config.leverage)
            
            # Hitung quantity
            ticker = await self.fetcher.exchange.fetch_ticker(ccxt_symbol)
            price = ticker['last']
            quantity = size_usd / price
            
            # Precision adjustment (simplified)
            quantity = round(quantity, 4)
            
            side = 'buy' if direction == TradeDirection.LONG else 'sell'
            
            # Place main order
            order = await self.fetcher.exchange.create_market_buy_order(
                ccxt_symbol, quantity
            ) if side == 'buy' else await self.fetcher.exchange.create_market_sell_order(
                ccxt_symbol, quantity
            )
            
            filled_price = order.get('average', order.get('price', price))
            filled_qty = order.get('filled', quantity)
            
            # Set TP/SL jika supported (Binance Futures via CCXT)
            if stop_loss or take_profit:
                await self._attach_tp_sl(
                    ccxt_symbol, side, filled_qty, 
                    stop_loss, take_profit
                )
            
            # Track position
            self.positions[symbol] = {
                'direction': direction.value,
                'entry_price': filled_price,
                'quantity': filled_qty,
                'stop_loss': stop_loss,
                'take_profit': take_profit,
                'size_usd': size_usd
            }
            
            logger.info(f"Order executed: {side} {quantity} {symbol} @ {filled_price}")
            
            return OrderResult(
                success=True,
                order_id=order.get('id'),
                filled_price=filled_price,
                filled_qty=filled_qty,
                fee=order.get('fee', {}).get('cost', 0)
            )
            
        except Exception as e:
            logger.error(f"Order execution failed: {e}")
            return OrderResult(success=False, order_id=None, filled_price=None, 
                             filled_qty=None, fee=None, error=str(e))
    
    async def _attach_tp_sl(
        self, 
        symbol: str, 
        side: str, 
        quantity: float,
        stop_loss: Optional[float],
        take_profit: Optional[float]
    ):
        """Attach stop loss dan take profit orders."""
        try:
            # TP/SL implementation depends on hedge mode vs one-way
            # Ini simplified version
            
            if stop_loss:
                sl_side = 'sell' if side == 'buy' else 'buy'
                await self.fetcher.exchange.create_order(
                    symbol, 'stop_market', sl_side, quantity, None, 
                    {'stopPrice': stop_loss}
                )
            
            if take_profit:
                tp_side = 'sell' if side == 'buy' else 'buy'
                await self.fetcher.exchange.create_order(
                    symbol, 'take_profit_market', tp_side, quantity, None,
                    {'stopPrice': take_profit}
                )
                
        except Exception as e:
            logger.error(f"Error attaching TP/SL: {e}")
    
    async def close_position(self, symbol: str) -> OrderResult:
        """Close existing position."""
        try:
            ccxt_symbol = symbol if '/' in symbol else symbol.replace('USDT', '/USDT')
            pos = self.positions.get(symbol)
            
            if not pos:
                return OrderResult(success=False, error="No position found")
            
            # Close dengan order berlawanan
            close_side = 'sell' if pos['direction'] == 'LONG' else 'buy'
            qty = pos['quantity']
            
            order = await self.fetcher.exchange.create_market_order(
                ccxt_symbol, close_side, qty, {'reduceOnly': True}
            )
            
            del self.positions[symbol]
            
            return OrderResult(
                success=True,
                order_id=order.get('id'),
                filled_price=order.get('average'),
                filled_qty=order.get('filled'),
                fee=order.get('fee', {}).get('cost', 0)
            )
            
        except Exception as e:
            return OrderResult(success=False, error=str(e))
    
    async def get_position(self, symbol: str) -> Optional[Dict]:
        """Get current position."""
        try:
            ccxt_symbol = symbol if '/' in symbol else symbol.replace('USDT', '/USDT')
            positions = await self.fetcher.exchange.fetch_positions([ccxt_symbol])
            for p in positions:
                if float(p.get('contracts', 0)) != 0:
                    return {
                        'symbol': symbol,
                        'side': p['side'],
                        'size': float(p['contracts']),
                        'entry_price': float(p['entryPrice']),
                        'unrealized_pnl': float(p['unrealizedPnl']),
                        'leverage': float(p['leverage'])
                    }
            return None
        except Exception as e:
            logger.error(f"Error fetching position: {e}")
            return None
