"""
Main Bot Orchestrator: menggabungkan semua komponen.
"""
import asyncio
import signal
import sys
from typing import Dict, Optional
from datetime import datetime

from config.settings import SETTINGS, SymbolConfig, TradeDirection
from config.credentials import CREDS
from core.decision_engine import DecisionEngine, TradeDecision
from core.executor import Executor
from analysis.ema import EMAAnalyzer
from analysis.macd import MACDAnalyzer
from analysis.rsi import RSIAnalyzer
from analysis.market_structure import MarketStructureAnalyzer
from onchain.whale_tracker import WhaleTracker
from onchain.funding_rate import FundingRateAnalyzer
from onchain.open_interest import OpenInterestAnalyzer
from ai.mirofish import MiroFishModel
from ai.sentiment import SentimentAnalyzer
from ai.claude_integration import ClaudeIntegration
from risk.risk_manager import RiskManager
from data.fetcher import DataFetcher
from data.preprocessor import DataPreprocessor
from data.storage import DataStorage
from utils.logger import get_logger
from utils.notifier import Notifier

logger = get_logger("core.bot")


class TradingBot:
    def __init__(self):
        self.running = False
        self.decision_engine = DecisionEngine()
        self.executor = Executor()
        self.risk_manager = RiskManager()
        self.fetcher = DataFetcher()
        self.preprocessor = DataPreprocessor()
        self.storage = DataStorage()
        self.notifier = Notifier()
        
        # Analysis modules
        self.ema = EMAAnalyzer()
        self.macd = MACDAnalyzer()
        self.rsi = RSIAnalyzer()
        self.market_structure = MarketStructureAnalyzer()
        
        # On-chain modules
        self.whale = WhaleTracker()
        self.funding = FundingRateAnalyzer()
        self.oi = OpenInterestAnalyzer()
        
        # AI modules
        self.mirofish = MiroFishModel()
        self.sentiment = SentimentAnalyzer()
        self.claude = ClaudeIntegration()
        
        self.current_decisions: Dict[str, TradeDecision] = {}
    
    async def initialize(self):
        """Initialize semua komponen."""
        logger.info("=" * 50)
        logger.info(f"AutoTrade Bot v{SETTINGS.version} initializing...")
        logger.info(f"Mode: {SETTINGS.mode.upper()} | Sandbox: {SETTINGS.sandbox}")
        logger.info("=" * 50)
        
        # Validate credentials
        try:
            CREDS.validate()
        except ValueError as e:
            logger.error(f"Credential validation failed: {e}")
            sys.exit(1)
        
        await self.executor.initialize()
        
        # Load ML model jika ada
        if not self.mirofish.load_model():
            logger.warning("No pre-trained MiroFish model found. Will train on first run.")
        
        # Setup signal handlers
        signal.signal(signal.SIGINT, self._signal_handler)
        signal.signal(signal.SIGTERM, self._signal_handler)
        
        self.running = True
        logger.info("Bot initialized successfully")
    
    def _signal_handler(self, signum, frame):
        """Handle shutdown gracefully."""
        logger.info("Shutdown signal received, stopping bot...")
        self.running = False
    
    async def analyze_symbol(self, symbol_config: SymbolConfig) -> TradeDecision:
        """Run full analysis pipeline untuk satu symbol."""
        symbol = symbol_config.symbol
        
        try:
            # 1. Fetch & preprocess data
            raw_df = await self.fetcher.fetch_ohlcv(symbol_config, limit=500)
            df = self.preprocessor.clean_ohlcv(raw_df)
            
            if len(df) < 100:
                logger.warning(f"Insufficient data for {symbol}")
                return TradeDecision(
                    direction=TradeDirection.NEUTRAL,
                    confidence=0.0,
                    position_size_pct=0,
                    signals=[],
                    regime=self.decision_engine.detect_regime(df),
                    reasoning="Insufficient data"
                )
            
            # Save to storage
            self.storage.save_ohlcv(df, symbol, symbol_config.timeframe)
            
            # 2. Technical Analysis
            df = self.ema.calculate(df)
            ema_signal = self.ema.detect_crossover(df)
            
            df = self.macd.calculate(df)
            macd_signal = self.macd.generate_signal(df)
            
            df = self.rsi.calculate(df)
            rsi_signal = self.rsi.generate_signal(df)
            
            ms_signal = self.market_structure.generate_signal(df)
            
            technical_signals = {
                'ema': ema_signal,
                'macd': macd_signal,
                'rsi': rsi_signal,
                'market_structure': ms_signal
            }
            
            # 3. On-Chain Analysis
            whale_df = await self.whale.fetch_whale_transactions(symbol.replace('/USDT', ''))
            whale_signal = self.whale.generate_signal(whale_df)
            
            funding_signal = await self.funding.fetch_and_analyze(self.fetcher, symbol)
            
            price_change = df['close'].iloc[-1] / df['close'].iloc[-2] - 1 if len(df) > 1 else 0
            oi_signal = await self.oi.generate_signal(symbol, price_change)
            
            onchain_signals = {
                'whale': whale_signal,
                'funding': funding_signal,
                'oi': oi_signal
            }
            
            # 4. AI Analysis
            mirofish_signal = self.mirofish.predict(df)
            
            sentiment_signal = await self.sentiment.generate_signal()
            
            # Claude integration (expensive, call less frequently or for high-confidence setups)
            claude_signal = {'signal': TradeDirection.NEUTRAL, 'confidence': 0, 'status': 'skipped'}
            if SETTINGS.mode == 'live':  # Only in live untuk menghemat cost
                tech_summary = f"EMA: {ema_signal.get('cross_type', 'none')}, MACD: {macd_signal.get('divergence', 'none')}"
                onchain_summary = f"Funding: {funding_signal.get('interpretation', 'neutral')}"
                sentiment_summary = f"F&G: {sentiment_signal.get('fear_greed', {}).get('value', 50)}"
                price_action = df.tail(5)[['open', 'high', 'low', 'close']].to_dict('records')
                
                claude_signal = await self.claude.analyze_market(
                    symbol, tech_summary, onchain_summary, sentiment_summary, price_action
                )
            
            ai_signals = {
                'mirofish': mirofish_signal,
                'sentiment': sentiment_signal,
                'claude': claude_signal
            }
            
            # 5. Decision Engine
            decision = self.decision_engine.aggregate_signals(
                technical_signals, onchain_signals, ai_signals, df
            )
            
            # Save signals
            for sig in decision.signals:
                self.storage.save_signal(
                    symbol, sig.source, sig.direction.value, 
                    sig.strength, sig.metadata or {}
                )
            
            self.current_decisions[symbol] = decision
            
            logger.info(
                f"[{symbol}] Decision: {decision.direction.value} | "
                f"Confidence: {decision.confidence:.2f} | "
                f"Regime: {decision.regime.value} | "
                f"Reason: {decision.reasoning[:50]}"
            )
            
            return decision
            
        except Exception as e:
            logger.error(f"Error analyzing {symbol}: {e}", exc_info=True)
            return TradeDecision(
                direction=TradeDirection.NEUTRAL,
                confidence=0.0,
                position_size_pct=0,
                signals=[],
                regime=self.decision_engine.detect_regime(df) if 'df' in locals() else None,
                reasoning=f"Error: {str(e)}"
            )
    
    async def execute_decision(self, symbol_config: SymbolConfig, decision: TradeDecision):
        """Execute trade decision jika memenuhi kriteria."""
        symbol = symbol_config.symbol
        
        if decision.direction == TradeDirection.NEUTRAL:
            return
        
        # Risk check
        balance_data = await self.fetcher.fetch_balance()
        available = 0.0
        if balance_data and 'USDT' in balance_data:
            available = balance_data['USDT'].get('free', 0)
        
        current_price = await self.fetcher.exchange.fetch_ticker(
            symbol if '/' in symbol else symbol.replace('USDT', '/USDT')
        )
        price = current_price['last'] if current_price else 0
        
        risk_result = self.risk_manager.pre_trade_check(
            symbol_config, 
            await self.fetcher.fetch_ohlcv(symbol_config, limit=100),  # Re-fetch untuk risk calc
            decision.direction,
            price,
            available
        )
        
        if not risk_result.allowed:
            logger.warning(f"Trade blocked by risk manager: {risk_result.reason}")
            await self.notifier.send_alert(
                f"🚫 Trade Blocked: {symbol}\nReason: {risk_result.reason}"
            )
            return
        
        # Execute
        if SETTINGS.mode == 'paper':
            logger.info(
                f"PAPER TRADE: {decision.direction.value} {symbol} | "
                f"Size: ${risk_result.position_size:.2f} | "
                f"SL: {risk_result.stop_loss:.2f} | TP: {risk_result.take_profit:.2f}"
            )
            await self.notifier.send_alert(
                f"📊 PAPER TRADE\n"
                f"Symbol: {symbol}\n"
                f"Direction: {decision.direction.value}\n"
                f"Size: ${risk_result.position_size:.2f}\n"
                f"Confidence: {decision.confidence:.2f}\n"
                f"SL: {risk_result.stop_loss:.2f}\n"
                f"TP: {risk_result.take_profit:.2f}"
            )
        else:
            # Live trading
            result = await self.executor.place_market_order(
                symbol_config,
                decision.direction,
                risk_result.position_size,
                stop_loss=risk_result.stop_loss,
                take_profit=risk_result.take_profit
            )
            
            if result.success:
                logger.info(f"LIVE TRADE executed: {result.order_id}")
                await self.notifier.send_alert(
                    f"🔴 LIVE TRADE EXECUTED\n"
                    f"Symbol: {symbol}\n"
                    f"Order ID: {result.order_id}\n"
                    f"Filled: {result.filled_qty} @ {result.filled_price}"
                )
            else:
                logger.error(f"Live trade failed: {result.error}")
                await self.notifier.send_alert(f"❌ Trade Failed: {result.error}")
    
    async def run_cycle(self):
        """Satu trading cycle."""
        logger.info("Starting new trading cycle...")
        
        for symbol_config in SETTINGS.symbols:
            if not self.running:
                break
            
            try:
                decision = await self.analyze_symbol(symbol_config)
                
                # Execute jika confidence cukup
                if decision.confidence >= SETTINGS.prediction_threshold:
                    await self.execute_decision(symbol_config, decision)
                
                await asyncio.sleep(1)  # Rate limit respect
                
            except Exception as e:
                logger.error(f"Cycle error for {symbol_config.symbol}: {e}")
                continue
        
        # Update risk equity
        try:
            balance = await self.fetcher.fetch_balance()
            total = balance.get('total', {}).get('USDT', 0)
            self.risk_manager.update_equity(total)
        except:
            pass
    
    async def run(self):
        """Main event loop."""
        await self.initialize()
        
        cycle_count = 0
        
        while self.running:
            try:
                await self.run_cycle()
                cycle_count += 1
                
                # Retrain model periodically
                if cycle_count % (SETTINGS.model_retrain_interval_hours * 12) == 0:
                    logger.info("Scheduled model retraining...")
                    # Load historical data dan retrain
                    # self.mirofish.train(historical_df)
                
                # Sleep antara cycles (sesuai timeframe, misal 1h = 3600s)
                # Untuk demo, sleep 60 detik
                sleep_time = 60 if SETTINGS.mode == 'paper' else 3600
                logger.info(f"Cycle complete. Sleeping {sleep_time}s...")
                await asyncio.sleep(sleep_time)
                
            except Exception as e:
                logger.critical(f"Main loop error: {e}", exc_info=True)
                await asyncio.sleep(60)
        
        # Cleanup
        await self.fetcher.close()
        logger.info("Bot stopped gracefully")
