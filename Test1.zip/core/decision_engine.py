"""
Decision Engine: Weighted signal aggregation & dynamic weight adjustment.
"""
import pandas as pd
from typing import Dict, List, Optional
from dataclasses import dataclass
from config.settings import (
    SETTINGS, SymbolConfig, TradeDirection, MarketRegime,
    TechnicalWeights, OnchainWeights, AIWeights
)
from utils.logger import get_logger

logger = get_logger("core.decision")


@dataclass
class Signal:
    source: str  # 'ema', 'macd', 'rsi', 'market_structure', 'whale', 'funding', 'oi', 'mirofish', 'sentiment', 'claude'
    direction: TradeDirection
    strength: float  # 0.0 - 1.0
    metadata: Dict = None


@dataclass
class TradeDecision:
    direction: TradeDirection
    confidence: float  # 0.0 - 1.0
    position_size_pct: float
    signals: List[Signal]
    regime: MarketRegime
    reasoning: str


class DecisionEngine:
    def __init__(self):
        self.technical_weights = SETTINGS.technical_weights
        self.onchain_weights = SETTINGS.onchain_weights
        self.ai_weights = SETTINGS.ai_weights
        self.threshold = SETTINGS.prediction_threshold
    
    def detect_regime(self, df: pd.DataFrame) -> MarketRegime:
        """
        Deteksi market regime berdasarkan volatilitas dan trend strength.
        """
        if len(df) < 50:
            return MarketRegime.UNKNOWN
        
        # ADX-like calculation (simplified)
        returns = df['close'].pct_change()
        volatility = returns.rolling(20).std().iloc[-1]
        vol_mean = returns.rolling(20).std().mean()
        
        # Trend strength via EMA alignment
        ema20 = df['close'].ewm(span=20).mean().iloc[-1]
        ema50 = df['close'].ewm(span=50).mean().iloc[-1]
        price = df['close'].iloc[-1]
        
        trending = abs(price - ema20) / price > 0.02  # >2% dari EMA20
        
        if volatility > vol_mean * 1.5:
            return MarketRegime.VOLATILE
        elif trending:
            return MarketRegime.TRENDING
        else:
            return MarketRegime.RANGING
    
    def adjust_weights(self, regime: MarketRegime):
        """Dynamic weight adjustment berdasarkan regime."""
        adjustment = SETTINGS.regime_weights_adjustment.get(regime, {})
        
        tech_mult = adjustment.get('technical', 0.33)
        onchain_mult = adjustment.get('onchain', 0.33)
        ai_mult = adjustment.get('ai', 0.34)
        
        # Normalize internal weights
        total = tech_mult + onchain_mult + ai_mult
        tech_mult /= total
        onchain_mult /= total
        ai_mult /= total
        
        return tech_mult, onchain_mult, ai_mult
    
    def aggregate_signals(
        self,
        technical_signals: Dict[str, Dict],
        onchain_signals: Dict[str, Dict],
        ai_signals: Dict[str, Dict],
        df: pd.DataFrame
    ) -> TradeDecision:
        """
        Aggregate semua signals dengan weighted scoring.
        """
        regime = self.detect_regime(df)
        tech_mult, onchain_mult, ai_mult = self.adjust_weights(regime)
        
        all_signals: List[Signal] = []
        bullish_score = 0.0
        bearish_score = 0.0
        total_weight = 0.0
        
        # Process technical signals
        tech_map = {
            'ema': (self.technical_weights.ema, technical_signals.get('ema')),
            'macd': (self.technical_weights.macd, technical_signals.get('macd')),
            'rsi': (self.technical_weights.rsi, technical_signals.get('rsi')),
            'market_structure': (self.technical_weights.market_structure, technical_signals.get('market_structure'))
        }
        
        for source, (weight, data) in tech_map.items():
            if data:
                sig = Signal(
                    source=source,
                    direction=data.get('signal', TradeDirection.NEUTRAL),
                    strength=data.get('strength', 0),
                    metadata=data
                )
                all_signals.append(sig)
                
                adj_weight = weight * tech_mult
                total_weight += adj_weight
                
                if sig.direction == TradeDirection.LONG:
                    bullish_score += sig.strength * adj_weight
                elif sig.direction == TradeDirection.SHORT:
                    bearish_score += sig.strength * adj_weight
        
        # Process on-chain signals
        onchain_map = {
            'whale': (self.onchain_weights.whale_tracker, onchain_signals.get('whale')),
            'funding': (self.onchain_weights.funding_rate, onchain_signals.get('funding')),
            'oi': (self.onchain_weights.open_interest, onchain_signals.get('oi'))
        }
        
        for source, (weight, data) in onchain_map.items():
            if data:
                sig = Signal(
                    source=source,
                    direction=data.get('signal', TradeDirection.NEUTRAL),
                    strength=data.get('strength', 0),
                    metadata=data
                )
                all_signals.append(sig)
                
                adj_weight = weight * onchain_mult
                total_weight += adj_weight
                
                if sig.direction == TradeDirection.LONG:
                    bullish_score += sig.strength * adj_weight
                elif sig.direction == TradeDirection.SHORT:
                    bearish_score += sig.strength * adj_weight
        
        # Process AI signals
        ai_map = {
            'mirofish': (self.ai_weights.mirofish, ai_signals.get('mirofish')),
            'sentiment': (self.ai_weights.sentiment, ai_signals.get('sentiment')),
            'claude': (self.ai_weights.claude, ai_signals.get('claude'))
        }
        
        for source, (weight, data) in ai_map.items():
            if data:
                sig = Signal(
                    source=source,
                    direction=data.get('signal', TradeDirection.NEUTRAL),
                    strength=data.get('strength', data.get('confidence', 0)),
                    metadata=data
                )
                all_signals.append(sig)
                
                adj_weight = weight * ai_mult
                total_weight += adj_weight
                
                if sig.direction == TradeDirection.LONG:
                    bullish_score += sig.strength * adj_weight
                elif sig.direction == TradeDirection.SHORT:
                    bearish_score += sig.strength * adj_weight
        
        # Calculate final decision
        direction = TradeDirection.NEUTRAL
        confidence = 0.0
        reasoning = "No conclusive signal"
        
        if total_weight > 0:
            bullish_score /= total_weight
            bearish_score /= total_weight
            
            net_score = bullish_score - bearish_score
            
            if net_score > 0.1:
                direction = TradeDirection.LONG
                confidence = min(1.0, net_score)
                reasoning = f"Bullish consensus ({bullish_score:.2f} vs {bearish_score:.2f})"
            elif net_score < -0.1:
                direction = TradeDirection.SHORT
                confidence = min(1.0, abs(net_score))
                reasoning = f"Bearish consensus ({bearish_score:.2f} vs {bullish_score:.2f})"
            else:
                reasoning = "Mixed signals, staying neutral"
        
        # Confidence threshold check
        if confidence < self.threshold:
            direction = TradeDirection.NEUTRAL
            reasoning += f" (confidence {confidence:.2f} below threshold {self.threshold})"
        
        # Position sizing based on confidence
        position_size_pct = confidence * 0.5  # Max 50% allocation at confidence 1.0
        
        return TradeDecision(
            direction=direction,
            confidence=confidence,
            position_size_pct=position_size_pct,
            signals=all_signals,
            regime=regime,
            reasoning=reasoning
        )
